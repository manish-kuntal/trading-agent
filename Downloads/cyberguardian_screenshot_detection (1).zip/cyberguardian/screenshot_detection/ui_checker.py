"""
UI Consistency Checker
- Detects abrupt paste boundaries (sharp rectangular edges in non-border areas)
- Font texture inconsistency (pasted text has different pixel density)
- Color banding / inconsistent background (copy-paste artifacts)
- Detects suspicious bright regions typical of ELA hotspots on pasted UI elements
"""

import cv2
import numpy as np
from PIL import Image


class UIConsistencyChecker:

    # ─── Edge / Boundary Analysis ───────────────────────────────────────────

    def check_paste_boundaries(self, image_path: str) -> dict:
        """
        Pasted UI elements create sharp rectangular edges inside the image.
        We look for internal rectangle-shaped contours with unusually sharp boundaries.
        """
        img = cv2.imread(image_path)
        if img is None:
            return {"paste_score": 0, "suspicious_rects": 0}

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape

        # Edge detection
        edges = cv2.Canny(gray, 80, 200)

        # Dilate to connect near-by edges
        kernel = np.ones((3, 3), np.uint8)
        edges_dilated = cv2.dilate(edges, kernel, iterations=1)

        contours, _ = cv2.findContours(edges_dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        image_area = h * w
        suspicious_rects = 0

        for cnt in contours:
            area = cv2.contourArea(cnt)
            # Only consider contours that are large but not the whole image
            if area < 2000 or area > image_area * 0.85:
                continue

            peri = cv2.arcLength(cnt, True)
            approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)

            if len(approx) == 4:
                # Check aspect ratio — very narrow tall/wide rects are UI elements
                x, y, rw, rh = cv2.boundingRect(approx)
                aspect = rw / (rh + 1e-6)
                if 0.1 < aspect < 10:
                    suspicious_rects += 1

        paste_score = min(suspicious_rects * 5, 100)

        return {
            "paste_score": round(paste_score, 2),
            "suspicious_rects": suspicious_rects,
        }

    # ─── Font Texture Consistency ───────────────────────────────────────────

    def check_font_consistency(self, image_path: str) -> dict:
        """
        Real screenshots have consistent font rendering from the same OS.
        Pasted/edited text shows different sub-pixel patterns.
        We measure local standard deviation in text regions — high variance = inconsistent.
        """
        img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            return {"font_score": 0}

        # Binary threshold to isolate text pixels
        _, text_mask = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

        # Compute local std deviation using a small kernel
        img_f = img.astype(np.float32)
        mean = cv2.blur(img_f, (5, 5))
        sq_mean = cv2.blur(img_f ** 2, (5, 5))
        local_std = np.sqrt(np.maximum(sq_mean - mean ** 2, 0))

        text_pixels = local_std[text_mask > 0]
        if len(text_pixels) < 100:
            return {"font_score": 0, "text_pixel_count": len(text_pixels)}

        # High variance of std values in text region = inconsistent font rendering
        font_var = float(text_pixels.std())
        font_score = min(font_var / 8, 100)  # empirical scale

        return {
            "font_score": round(font_score, 2),
            "text_std_variance": round(font_var, 4),
            "text_pixel_count": int(len(text_pixels)),
        }

    # ─── Color Histogram Anomaly ────────────────────────────────────────────

    def check_color_anomaly(self, image_path: str) -> dict:
        """
        Detect unnatural color patches — pixel blobs with color that doesn't
        fit the overall color distribution of the image (typical of pasted logos,
        amounts, or status indicators).
        """
        img = cv2.imread(image_path)
        if img is None:
            return {"color_anomaly_score": 0}

        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        h_channel = hsv[:, :, 0].flatten()
        s_channel = hsv[:, :, 1].flatten()

        # Find hue peaks — too many sharp distinct peaks = multiple pasted elements
        h_hist = np.bincount(h_channel, minlength=180)
        peaks_over_threshold = int((h_hist > h_hist.mean() + 3 * h_hist.std()).sum())

        # Highly saturated isolated blobs (unnatural for screenshots)
        high_sat_mask = s_channel > 200
        high_sat_ratio = float(high_sat_mask.sum() / len(s_channel))

        anomaly_score = min(peaks_over_threshold * 4 + high_sat_ratio * 100, 100)

        return {
            "color_anomaly_score": round(anomaly_score, 2),
            "hue_peaks": peaks_over_threshold,
            "high_saturation_ratio": round(high_sat_ratio, 4),
        }

    # ─── Composite ─────────────────────────────────────────────────────────

    def analyze(self, image_path: str) -> dict:
        paste = self.check_paste_boundaries(image_path)
        font = self.check_font_consistency(image_path)
        color = self.check_color_anomaly(image_path)

        ui_score = (
            paste.get("paste_score", 0) * 0.45
            + font.get("font_score", 0) * 0.35
            + color.get("color_anomaly_score", 0) * 0.20
        )

        return {
            "ui_risk_score": round(ui_score, 2),
            "paste_boundary": paste,
            "font_consistency": font,
            "color_anomaly": color,
        }
