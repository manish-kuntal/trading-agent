"""
LLM Explainer — Google Gemini API
Replaces Ollama. Uses GEMINI_API_KEY from environment (.env loaded by bat file).
Falls back to rule-based if API key missing or quota exceeded.
"""

import os
import requests
from . import config


class LLMExplainer:

    API_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

    def __init__(self):
        self.api_key = os.environ.get("GEMINI_API_KEY", "").strip()
        self.model   = config.GEMINI_MODEL  # "gemini-2.0-flash"
        self.timeout = 30

    # ─── Public ──────────────────────────────────────────────────────────────

    def explain(self, analysis_summary: dict, risk_score: float, risk_level: str) -> dict:
        if not self.api_key:
            return self._fallback(risk_level, reason="No API key")

        prompt = self._build_prompt(analysis_summary, risk_score, risk_level)
        url    = self.API_URL.format(model=self.model) + f"?key={self.api_key}"

        payload = {
            "contents": [
                {"parts": [{"text": prompt}]}
            ],
            "generationConfig": {
                "temperature": 0.1,
                "maxOutputTokens": 400,
                "topK": 10,
                "topP": 0.8,
            },
            "safetySettings": [
                {"category": "HARM_CATEGORY_HARASSMENT",        "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_HATE_SPEECH",       "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
            ],
        }

        try:
            resp = requests.post(url, json=payload, timeout=self.timeout)
            resp.raise_for_status()
            data = resp.json()

            candidates = data.get("candidates", [])
            if not candidates:
                return self._fallback(risk_level, reason="Empty response")

            text = candidates[0]["content"]["parts"][0]["text"].strip()
            return {"explanation": text, "llm_used": self.model, "success": True}

        except requests.exceptions.HTTPError as e:
            status = e.response.status_code if e.response else 0
            if status == 429:
                return self._fallback(risk_level, reason="Quota exceeded")
            elif status == 400:
                return self._fallback(risk_level, reason="Invalid API key")
            return self._fallback(risk_level, reason=str(e))

        except requests.exceptions.Timeout:
            return self._fallback(risk_level, reason="Gemini timeout")

        except Exception as e:
            return self._fallback(risk_level, reason=str(e))

    # ─── Prompt ──────────────────────────────────────────────────────────────

    def _build_prompt(self, data: dict, risk_score: float, risk_level: str) -> str:
        keywords   = data.get("matched_scam_keywords", [])
        meta_flags = data.get("metadata_flags", [])
        amounts    = data.get("amounts_detected", [])
        app        = data.get("payment_app_detected") or "Unknown"
        txn_ids    = data.get("txn_ids_detected", [])
        text_prev  = data.get("text_preview", "")[:300]

        return f"""You are CyberGuardian, an AI cybersecurity assistant for Indian users.
Analyze this payment screenshot analysis and give a short, clear verdict.

SCORES (0-100, higher = more suspicious):
- Overall Risk   : {risk_score}/100 ({risk_level})
- Forensic (ELA) : {data.get('forensic_score','?')}/100
- OCR patterns   : {data.get('ocr_risk_score','?')}/100
- UI consistency : {data.get('ui_risk_score','?')}/100
- Metadata       : {data.get('metadata_risk_score','?')}/100

FINDINGS:
- Scam keywords  : {keywords or 'None'}
- Transaction IDs: {txn_ids or 'None found'}
- Amounts seen   : {amounts or 'None'}
- Payment app    : {app}
- Metadata flags : {meta_flags or 'None'}
- OCR text sample: {text_prev}

RESPOND IN THIS FORMAT ONLY:
VERDICT: [FAKE / SUSPICIOUS / AUTHENTIC]
REASONS:
1. [reason]
2. [reason]
3. [reason]
ACTION: [What the user should do — 1 sentence in simple English]

Keep total response under 150 words. No markdown. No extra text."""

    # ─── Fallback ────────────────────────────────────────────────────────────

    def _fallback(self, risk_level: str, reason: str = "") -> dict:
        messages = {
            "LOW": (
                "VERDICT: AUTHENTIC\nREASONS:\n1. No forensic tampering detected\n"
                "2. No scam keywords found\n3. Metadata appears normal\n"
                "ACTION: Screenshot looks authentic, but always verify in your bank app."
            ),
            "MEDIUM": (
                "VERDICT: SUSPICIOUS\nREASONS:\n1. Minor image anomalies detected\n"
                "2. Suspicious text patterns found\n3. Metadata inconsistencies present\n"
                "ACTION: Do NOT act on this — open your bank/UPI app to verify the transaction."
            ),
            "HIGH": (
                "VERDICT: SUSPICIOUS\nREASONS:\n1. ELA detected image tampering\n"
                "2. Scam-related keywords present\n3. UI inconsistencies detected\n"
                "ACTION: Likely manipulated. Verify via bank app and report to cybercrime.gov.in."
            ),
            "CRITICAL": (
                "VERDICT: FAKE\nREASONS:\n1. Strong forensic evidence of editing\n"
                "2. Multiple scam indicators in text\n3. Metadata shows editing software\n"
                "ACTION: Screenshot is FAKE. Do not pay. Report at cybercrime.gov.in immediately."
            ),
        }
        return {
            "explanation": messages.get(risk_level, "Analysis complete. Verify independently."),
            "llm_used":    f"rule-based-fallback ({reason})" if reason else "rule-based-fallback",
            "success":     True,
        }
