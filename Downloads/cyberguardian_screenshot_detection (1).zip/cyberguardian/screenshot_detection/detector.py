"""
ScreenshotDetector — Main Orchestrator
Runs all modules in sequence and returns a unified analysis result.

Usage:
    detector = ScreenshotDetector()
    result = detector.analyze_file("path/to/screenshot.png")
    result = detector.analyze_bytes(raw_image_bytes)
"""

import os
import tempfile
from pathlib import Path
from PIL import Image

from .forensics import ForensicAnalyzer
from .ocr_analyzer import OCRAnalyzer
from .metadata_checker import MetadataChecker
from .ui_checker import UIConsistencyChecker
from .risk_engine import RiskEngine
from .llm_explainer import LLMExplainer
from . import config


class ScreenshotDetector:

    def __init__(self, use_llm: bool = True):
        self.forensic   = ForensicAnalyzer()
        self.ocr        = OCRAnalyzer()
        self.metadata   = MetadataChecker()
        self.ui_checker = UIConsistencyChecker()
        self.risk_engine = RiskEngine()
        self.llm        = LLMExplainer() if use_llm else None

    # ─── Public API ──────────────────────────────────────────────────────────

    def analyze_file(self, image_path: str) -> dict:
        """Analyze an image file directly."""
        std_path = self._preprocess(image_path)
        try:
            return self._run_pipeline(std_path, original_path=image_path)
        finally:
            # Clean up standardized copy only if it's different from original
            if std_path != image_path and os.path.exists(std_path):
                os.remove(std_path)

    def analyze_bytes(self, image_bytes: bytes, suffix: str = ".png") -> dict:
        """Analyze raw image bytes (used by FastAPI endpoint)."""
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
            f.write(image_bytes)
            tmp_path = f.name
        try:
            return self.analyze_file(tmp_path)
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)

    # ─── Pipeline ────────────────────────────────────────────────────────────

    def _run_pipeline(self, image_path: str, original_path: str) -> dict:
        # Step 1: Parallel-ish analysis (sequential but modular)
        forensic_result  = self.forensic.analyze(image_path)
        ocr_result       = self.ocr.analyze(image_path)
        metadata_result  = self.metadata.analyze(original_path)  # original for EXIF
        ui_result        = self.ui_checker.analyze(image_path)

        # Step 2: Risk aggregation
        risk_result = self.risk_engine.calculate(
            forensic_score  = forensic_result["forensic_score"],
            ocr_score       = ocr_result["ocr_risk_score"],
            ui_score        = ui_result["ui_risk_score"],
            metadata_score  = metadata_result["metadata_risk_score"],
        )

        # Step 3: LLM explanation
        llm_result = {"explanation": None, "llm_used": None, "success": False}
        if self.llm:
            summary = {
                "forensic_score":         forensic_result["forensic_score"],
                "ocr_risk_score":         ocr_result["ocr_risk_score"],
                "ui_risk_score":          ui_result["ui_risk_score"],
                "metadata_risk_score":    metadata_result["metadata_risk_score"],
                "matched_scam_keywords":  ocr_result.get("matched_scam_keywords", []),
                "metadata_flags":         metadata_result.get("flags", []),
                "amounts_detected":       ocr_result.get("amounts_detected", []),
                "payment_app_detected":   ocr_result.get("payment_app_detected"),
                "txn_ids_detected":       ocr_result.get("txn_ids_detected", []),
                "text_preview":           ocr_result.get("text_preview", ""),
            }
            llm_result = self.llm.explain(
                summary,
                risk_result["risk_score"],
                risk_result["risk_level"],
            )

        # Step 4: Build final response
        return {
            # Top-level summary (Flutter uses these directly)
            "risk_score":      risk_result["risk_score"],
            "verdict":         risk_result["verdict"],
            "risk_level":      risk_result["risk_level"],
            "color":           risk_result["color"],
            "recommendation":  risk_result["recommendation"],
            "explanation":     llm_result.get("explanation"),

            # Component scores
            "component_scores": risk_result["component_scores"],

            # Detailed results (for dashboard/debug)
            "details": {
                "forensic":  forensic_result,
                "ocr":       ocr_result,
                "ui":        ui_result,
                "metadata":  metadata_result,
            },

            # Meta
            "llm_model": llm_result.get("llm_used"),
            "analysis_version": "1.0.0",
        }

    # ─── Preprocessing ───────────────────────────────────────────────────────

    def _preprocess(self, image_path: str) -> str:
        """
        Standardize image:
        - Convert to RGB
        - Resize to max 2000px (memory safety)
        - Save as PNG for lossless processing
        """
        img = Image.open(image_path)

        if img.mode not in ("RGB", "L"):
            img = img.convert("RGB")

        max_px = config.MAX_IMAGE_SIZE
        if max(img.size) > max_px:
            img.thumbnail((max_px, max_px), Image.LANCZOS)

        # Save standardized copy
        p = Path(image_path)
        std_path = str(p.parent / (p.stem + "_cg_std.png"))
        img.save(std_path, "PNG")
        return std_path
