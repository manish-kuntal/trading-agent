from .detector import ScreenshotDetector

__all__ = ["ScreenshotDetector"]
