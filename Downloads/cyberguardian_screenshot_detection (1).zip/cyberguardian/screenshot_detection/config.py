"""
CyberGuardian - Screenshot Detection Config
"""

# ── Gemini API ────────────────────────────────────────────────────────────────
# API key is loaded from .env by start_cyberguardian.bat
# Available models (free tier): gemini-2.0-flash, gemini-1.5-flash
GEMINI_MODEL = "gemini-2.0-flash"

# ── PaddleOCR ─────────────────────────────────────────────────────────────────
OCR_LANG    = "en"     # "ch" detects Hindi better (uses multilingual model)
OCR_USE_GPU = True     # Set False if CUDA issues

# ── ELA (Error Level Analysis) ────────────────────────────────────────────────
ELA_QUALITY = 90       # JPEG re-save quality
ELA_SCALE   = 10       # Amplification factor

# ── Image preprocessing ───────────────────────────────────────────────────────
MAX_IMAGE_SIZE = 2000  # Max pixels (width or height)

# ── Risk score weights (must sum to 1.0) ─────────────────────────────────────
WEIGHTS = {
    "forensic": 0.35,
    "ocr":      0.25,
    "ui":       0.20,
    "metadata": 0.20,
}

# ── Verdict thresholds ────────────────────────────────────────────────────────
THRESHOLDS = {
    "low":    25,   # 0-25:  Likely authentic
    "medium": 50,   # 25-50: Suspicious
    "high":   75,   # 50-75: Highly suspicious
                    # 75+:   Likely fake
}

# ── Indian UPI scam keywords ──────────────────────────────────────────────────
SCAM_KEYWORDS_EN = [
    "payment successful", "transaction successful", "paid successfully",
    "amount received", "money credited", "credited to your account",
    "rs. credited", "credited", "upi transaction id",
    "send screenshot", "screenshot proof", "show proof",
    "within 24 hours", "immediately transfer", "refund initiated",
    "otp required", "account blocked", "kyc update", "kyc expired",
    "lottery winner", "you have won", "claim prize", "congratulations you",
    "helpline", "toll free", "customer care", "call back",
    "pending approval", "process failed", "reverse payment",
]

SCAM_KEYWORDS_HI = [
    "भुगतान सफल", "राशि जमा", "सफलतापूर्वक भेजा",
    "पैसे प्राप्त हुए", "खाते में जमा", "ओटीपी दर्ज करें",
    "खाता ब्लॉक", "केवाईसी", "लॉटरी", "इनाम",
    "तुरंत भेजें", "अभी भेजें",
]

ALL_SCAM_KEYWORDS = SCAM_KEYWORDS_EN + SCAM_KEYWORDS_HI

# ── Known legitimate UPI app names ───────────────────────────────────────────
LEGIT_UPI_APPS = [
    "phonepe", "phone pe", "gpay", "google pay",
    "paytm", "bhim", "amazon pay", "icici imobile",
    "yono sbi", "axis pay", "hdfc", "kotak",
]
