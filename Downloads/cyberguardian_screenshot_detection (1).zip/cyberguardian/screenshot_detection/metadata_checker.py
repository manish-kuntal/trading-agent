"""
Metadata Checker
- Analyzes EXIF data for inconsistencies
- Real phone screenshots have minimal EXIF
- Edited images often carry camera EXIF or missing/stripped metadata
- File format mismatches (saved as PNG but internals say JPEG = re-saved)
"""

import os
from PIL import Image
from PIL.ExifTags import TAGS


class MetadataChecker:

    # Camera-specific EXIF tags that should NOT be in a screenshot
    _CAMERA_TAGS = {
        "Make", "Model", "ExposureTime", "FNumber", "ISOSpeedRatings",
        "ShutterSpeedValue", "ApertureValue", "Flash", "FocalLength",
        "GPSInfo", "MeteringMode", "WhiteBalance", "ExposureProgram",
        "SceneCaptureType",
    }

    # Software tags that hint at editing tools
    _EDITING_SOFTWARE = [
        "photoshop", "lightroom", "gimp", "pixlr", "canva",
        "snapseed", "facetune", "afterlight", "vsco",
        "adobe", "corel", "paint.net", "affinity",
    ]

    def analyze(self, image_path: str) -> dict:
        flags: list[str] = []
        risk_score = 0

        try:
            img = Image.open(image_path)
        except Exception as e:
            return {
                "metadata_risk_score": 30,
                "flags": [f"Could not open image: {e}"],
                "image_format": "unknown",
                "image_size": [0, 0],
                "image_mode": "unknown",
                "file_size_bytes": 0,
                "has_exif": False,
                "exif_tags": [],
            }

        file_size = os.path.getsize(image_path)
        exif_data: dict = {}

        # ── EXIF extraction ────────────────────────────────────────────────
        try:
            raw_exif = img._getexif()
            if raw_exif:
                for tag_id, value in raw_exif.items():
                    tag_name = TAGS.get(tag_id, str(tag_id))
                    exif_data[tag_name] = str(value)
        except Exception:
            pass

        # ── Camera EXIF in screenshot → suspicious ─────────────────────────
        found_camera_tags = [t for t in self._CAMERA_TAGS if t in exif_data]
        if found_camera_tags:
            risk_score += 25
            flags.append(f"Camera EXIF present: {found_camera_tags} — image may be a photo of a screen or edited")

        # ── Editing software ───────────────────────────────────────────────
        software = exif_data.get("Software", "").lower()
        if software:
            for sw in self._EDITING_SOFTWARE:
                if sw in software:
                    risk_score += 30
                    flags.append(f"Edited with: {exif_data.get('Software', 'unknown editor')}")
                    break

        # ── JPEG without camera metadata ───────────────────────────────────
        # Authentic screenshots saved as JPEG by the OS usually have minimal metadata
        # But JPEG with NO metadata at all after editing is also suspicious
        if img.format == "JPEG":
            if not exif_data:
                risk_score += 10
                flags.append("JPEG with stripped metadata — possible re-save after editing")
            elif not found_camera_tags:
                risk_score += 5
                flags.append("JPEG without matching camera metadata")

        # ── Unusual DPI ────────────────────────────────────────────────────
        dpi = img.info.get("dpi", (72, 72))
        if isinstance(dpi, tuple) and len(dpi) == 2:
            if not (50 <= dpi[0] <= 120):
                risk_score += 5
                flags.append(f"Unusual DPI: {dpi} — screenshots are typically 72–96 DPI")

        # ── File modification vs creation time delta ───────────────────────
        try:
            stat = os.stat(image_path)
            delta = abs(stat.st_mtime - stat.st_ctime)
            if delta > 7200:  # 2-hour gap
                risk_score += 5
                flags.append("Significant gap between file creation and modification times")
        except Exception:
            pass

        # ── Image mode sanity ──────────────────────────────────────────────
        if img.mode not in ("RGB", "RGBA", "L"):
            risk_score += 5
            flags.append(f"Unusual color mode: {img.mode}")

        risk_score = min(risk_score, 100)

        return {
            "metadata_risk_score": risk_score,
            "flags": flags,
            "image_format": img.format or "unknown",
            "image_size": list(img.size),
            "image_mode": img.mode,
            "file_size_bytes": file_size,
            "has_exif": bool(exif_data),
            "exif_tags": list(exif_data.keys()),
            "software_tag": exif_data.get("Software", None),
        }
