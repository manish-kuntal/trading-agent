"""
Forensic Image Analysis
- Error Level Analysis (ELA): Detects tampered regions by re-saving at known quality
- Noise Analysis: Detects inconsistent noise patterns (pasted regions have different noise)
- JPEG Ghost Analysis: Detects double-JPEG compression (common in edited images)
"""

import cv2
import numpy as np
from PIL import Image, ImageChops, ImageEnhance
import io
from . import config


class ForensicAnalyzer:

    def __init__(self):
        self.ela_quality = config.ELA_QUALITY
        self.ela_scale = config.ELA_SCALE

    # ─── ELA ───────────────────────────────────────────────────────────────────

    def error_level_analysis(self, image_path: str) -> dict:
        """
        Re-save image at known JPEG quality, compute pixel diff.
        High diff → likely tampered region (edited/pasted content was re-saved
        at a different quality than the surrounding image).
        """
        original = Image.open(image_path).convert("RGB")

        buf = io.BytesIO()
        original.save(buf, "JPEG", quality=self.ela_quality)
        buf.seek(0)
        compressed = Image.open(buf).convert("RGB")

        diff = ImageChops.difference(original, compressed)
        extrema = diff.getextrema()
        max_diff = max(ex[1] for ex in extrema)

        scale = (255.0 / max_diff) if max_diff > 0 else 1
        diff_enhanced = ImageEnhance.Brightness(diff).enhance(scale * self.ela_scale)

        ela_arr = np.array(diff_enhanced)
        mean_ela = float(ela_arr.mean())
        std_ela = float(ela_arr.std())

        threshold = mean_ela + 2 * std_ela
        suspicious_ratio = float((ela_arr > threshold).sum() / ela_arr.size)

        # Scale to 0-100; suspicious ratio of 0.2+ is very bad
        ela_score = min(suspicious_ratio * 500, 100)

        return {
            "ela_score": round(ela_score, 2),
            "mean_ela": round(mean_ela, 3),
            "std_ela": round(std_ela, 3),
            "suspicious_pixel_ratio": round(suspicious_ratio, 4),
        }

    # ─── Noise Analysis ────────────────────────────────────────────────────────

    def noise_analysis(self, image_path: str) -> dict:
        """
        Real screenshots have uniform sensor/compression noise across the image.
        Pasted/edited regions break this uniformity.
        Measure per-block noise std; high variance across blocks = suspicious.
        """
        img = cv2.imread(image_path)
        if img is None:
            return {"noise_inconsistency_score": 0, "noise_mean": 0, "noise_std": 0}

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (7, 7), 0)
        noise = cv2.subtract(gray, blur)

        block_size = 32
        h, w = noise.shape
        block_stds = []

        for y in range(0, h - block_size, block_size):
            for x in range(0, w - block_size, block_size):
                block = noise[y : y + block_size, x : x + block_size]
                block_stds.append(float(block.std()))

        if not block_stds:
            return {"noise_inconsistency_score": 0, "noise_mean": 0, "noise_std": 0}

        arr = np.array(block_stds)
        noise_mean = float(arr.mean())
        noise_std = float(arr.std())

        # Coefficient of variation across blocks
        inconsistency = min((noise_std / (noise_mean + 1e-6)) * 50, 100)

        return {
            "noise_inconsistency_score": round(inconsistency, 2),
            "noise_mean": round(noise_mean, 4),
            "noise_std": round(noise_std, 4),
        }

    # ─── JPEG Ghost ────────────────────────────────────────────────────────────

    def jpeg_ghost_analysis(self, image_path: str) -> dict:
        """
        JPEG ghost: if an image was saved, edited, re-saved, certain compression
        artifacts repeat. We test at multiple quality levels and find the one with
        minimum reconstruction error — lower quality match = more re-compressions.
        """
        img = cv2.imread(image_path)
        if img is None:
            return {"ghost_score": 0, "estimated_quality": 100, "double_compressed": False}

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(float)
        pil_img = Image.fromarray(img[:, :, ::-1])  # BGR→RGB

        min_mse = float("inf")
        best_quality = 100

        for q in [60, 70, 80, 90, 95]:
            buf = io.BytesIO()
            pil_img.save(buf, "JPEG", quality=q)
            buf.seek(0)
            recomp = np.array(Image.open(buf).convert("L")).astype(float)
            mse = float(np.mean((gray - recomp) ** 2))
            if mse < min_mse:
                min_mse = mse
                best_quality = q

        # If best match is at low quality, image likely went through multiple saves
        ghost_score = max(0, (100 - best_quality) * 1.5)

        return {
            "ghost_score": round(ghost_score, 2),
            "estimated_quality": best_quality,
            "double_compressed": best_quality < 90,
        }

    # ─── Composite ─────────────────────────────────────────────────────────────

    def analyze(self, image_path: str) -> dict:
        ela = self.error_level_analysis(image_path)
        noise = self.noise_analysis(image_path)
        ghost = self.jpeg_ghost_analysis(image_path)

        forensic_score = (
            ela["ela_score"] * 0.50
            + noise["noise_inconsistency_score"] * 0.30
            + ghost["ghost_score"] * 0.20
        )

        return {
            "forensic_score": round(forensic_score, 2),
            "ela": ela,
            "noise": noise,
            "jpeg_ghost": ghost,
        }
