"""
Risk Score Engine
Aggregates scores from forensics, OCR, UI, and metadata modules
into a final 0–100 risk score with verdict and recommendations.
"""

from . import config


class RiskEngine:

    VERDICTS = [
        (config.THRESHOLDS["low"],    "LIKELY AUTHENTIC", "LOW",      "#22c55e"),  # green
        (config.THRESHOLDS["medium"], "SUSPICIOUS",       "MEDIUM",   "#eab308"),  # yellow
        (config.THRESHOLDS["high"],   "HIGHLY SUSPICIOUS","HIGH",     "#f97316"),  # orange
        (101,                         "LIKELY FAKE",      "CRITICAL",  "#ef4444"),  # red
    ]

    RECOMMENDATIONS = {
        "LOW":      "Screenshot appears authentic. Proceed with caution and verify through official app.",
        "MEDIUM":   "Some anomalies detected. Do NOT act on this screenshot without verifying the transaction in your bank app.",
        "HIGH":     "Multiple red flags detected. This screenshot is likely manipulated. Report to cybercrime.",
        "CRITICAL": "Screenshot is almost certainly fake/edited. DO NOT pay or act on this. File a complaint at cybercrime.gov.in",
    }

    def calculate(
        self,
        forensic_score: float,
        ocr_score: float,
        ui_score: float,
        metadata_score: float,
    ) -> dict:
        w = config.WEIGHTS
        raw = (
            forensic_score * w["forensic"]
            + ocr_score    * w["ocr"]
            + ui_score     * w["ui"]
            + metadata_score * w["metadata"]
        )
        risk_score = round(min(raw, 100.0), 2)

        # Verdict
        verdict = risk_level = color = ""
        for threshold, v, level, c in self.VERDICTS:
            if risk_score < threshold:
                verdict, risk_level, color = v, level, c
                break

        recommendation = self.RECOMMENDATIONS[risk_level]

        return {
            "risk_score": risk_score,
            "verdict": verdict,
            "risk_level": risk_level,
            "color": color,
            "recommendation": recommendation,
            "component_scores": {
                "forensic":  round(forensic_score,  2),
                "ocr":       round(ocr_score,       2),
                "ui":        round(ui_score,        2),
                "metadata":  round(metadata_score,  2),
            },
            "weights_used": w,
        }
