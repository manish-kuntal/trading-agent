"""
OCR Analyzer
- Extracts text from screenshot using PaddleOCR
- Detects scam keywords (English + Hindi)
- Validates UPI IDs and amounts
- Checks for red-flag phrases used in fake payment screenshots
"""

import re
import numpy as np
from typing import Optional
from . import config


# Lazy-load PaddleOCR to avoid startup slowness when not needed
_ocr_instance: Optional[object] = None


def _get_ocr():
    global _ocr_instance
    if _ocr_instance is None:
        from paddleocr import PaddleOCR
        try:
            _ocr_instance = PaddleOCR(
                use_angle_cls=True,
                lang=config.OCR_LANG,
                use_gpu=config.OCR_USE_GPU,
                show_log=False,
            )
        except Exception:
            # CPU fallback
            _ocr_instance = PaddleOCR(
                use_angle_cls=True,
                lang=config.OCR_LANG,
                use_gpu=False,
                show_log=False,
            )
    return _ocr_instance


# Compiled regex patterns
_UPI_RE = re.compile(r"[\w.\-]{3,}@[\w]{3,}")
_AMOUNT_RE = re.compile(
    r"(?:₹|rs\.?\s*|inr\s*)[\d,]+(?:\.\d{1,2})?|[\d,]+(?:\.\d{1,2})?\s*(?:₹|rs\.?|rupees?)",
    re.IGNORECASE,
)
_TXN_ID_RE = re.compile(r"(?:upi\s*ref|txn\s*id|transaction\s*id|ref\s*no)[:\s#]*([A-Z0-9]{8,20})", re.IGNORECASE)


class OCRAnalyzer:

    def extract_text(self, image_path: str) -> dict:
        """Run PaddleOCR and return raw text lines + confidence."""
        ocr = _get_ocr()
        result = ocr.ocr(image_path, cls=True)

        texts: list[str] = []
        confidences: list[float] = []

        if result and result[0]:
            for line in result[0]:
                if line and len(line) >= 2:
                    text, conf = line[1][0], line[1][1]
                    texts.append(text)
                    confidences.append(float(conf))

        avg_conf = float(np.mean(confidences)) if confidences else 0.0
        full_text = " ".join(texts).lower()

        return {
            "lines": texts,
            "full_text": full_text,
            "avg_confidence": round(avg_conf, 3),
            "line_count": len(texts),
        }

    def analyze_patterns(self, ocr_data: dict) -> dict:
        """
        Pattern matching on extracted text.
        Returns risk score + detected patterns.
        """
        full_text = ocr_data["full_text"]
        risk_score = 0
        matched_keywords: list[str] = []
        flags: list[str] = []

        # 1. Scam keyword matching
        for kw in config.ALL_SCAM_KEYWORDS:
            if kw.lower() in full_text:
                matched_keywords.append(kw)
                risk_score += 8

        if matched_keywords:
            flags.append(f"Scam keywords found: {matched_keywords[:5]}")

        # 2. UPI ID extraction & validation
        upi_ids = _UPI_RE.findall(full_text)

        # 3. Amount extraction
        amounts = _AMOUNT_RE.findall(full_text)

        # Multiple different amounts in one screenshot = suspicious (amount tampering)
        if len(amounts) > 3:
            risk_score += 15
            flags.append("Multiple amounts detected — possible amount substitution")

        # 4. Transaction ID check
        txn_ids = _TXN_ID_RE.findall(ocr_data["full_text"])  # case-sensitive original
        if not txn_ids and any(kw in full_text for kw in ["successful", "सफल", "credited"]):
            risk_score += 20
            flags.append("Payment success claimed but no valid transaction ID found")

        # 5. Low OCR confidence = blurry/edited text
        if ocr_data["avg_confidence"] < 0.80:
            risk_score += 15
            flags.append(f"Low OCR confidence ({ocr_data['avg_confidence']:.2f}) — text may be edited or low quality")
        elif ocr_data["avg_confidence"] < 0.90:
            risk_score += 5

        # 6. Detect payment app mention
        app_detected = None
        for app in config.LEGIT_UPI_APPS:
            if app in full_text:
                app_detected = app
                break

        # 7. Unusual character mixing (leet-speak to evade keyword filters)
        leet_pattern = re.search(r"[₹р𝕣ꝛ]|\b[1l][0o][t7][t7][e3]ry\b", full_text)
        if leet_pattern:
            risk_score += 10
            flags.append("Unusual character substitution detected")

        risk_score = min(risk_score, 100)

        return {
            "ocr_risk_score": risk_score,
            "matched_scam_keywords": matched_keywords,
            "upi_ids_detected": upi_ids,
            "amounts_detected": amounts,
            "txn_ids_detected": txn_ids,
            "payment_app_detected": app_detected,
            "flags": flags,
            "text_preview": full_text[:400],
        }

    def analyze(self, image_path: str) -> dict:
        ocr_data = self.extract_text(image_path)
        pattern_data = self.analyze_patterns(ocr_data)
        return {**ocr_data, **pattern_data}
