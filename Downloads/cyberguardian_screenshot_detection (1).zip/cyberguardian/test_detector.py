"""
Test script for CyberGuardian Screenshot Detector.
Run: python test_detector.py <path_to_image>
Or:  python test_detector.py  (uses a synthetic test image)
"""

import sys
import json
import os
import numpy as np


def create_synthetic_test_image(path: str):
    """Creates a fake 'payment success' screenshot for testing."""
    from PIL import Image, ImageDraw, ImageFont

    img = Image.new("RGB", (720, 1280), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)

    # Simulate a PhonePe-style layout (simple)
    draw.rectangle([0, 0, 720, 120], fill=(75, 0, 130))   # purple header
    draw.text((240, 45), "PhonePe", fill=(255, 255, 255))

    draw.text((200, 200), "Payment Successful", fill=(34, 139, 34))
    draw.text((220, 280), "₹ 5,000.00", fill=(0, 0, 0))
    draw.text((180, 360), "To: 9876543210@paytm", fill=(80, 80, 80))
    draw.text((180, 420), "UPI Ref: PHONEP123456789", fill=(80, 80, 80))
    draw.text((180, 480), "Date: 03 Aug 2026, 10:30 AM", fill=(80, 80, 80))

    # ── Simulate tampered region (paste a different-colored block for the amount)
    # This creates an ELA-detectable inconsistency
    paste_block = Image.new("RGB", (300, 60), color=(255, 250, 200))
    paste_draw = ImageDraw.Draw(paste_block)
    paste_draw.text((50, 15), "₹ 50,000.00", fill=(255, 0, 0))
    img.paste(paste_block, (210, 260))  # Paste over original amount

    img.save(path, "JPEG", quality=85)
    print(f"  [test] Synthetic test image created: {path}")


def main():
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
        if not os.path.exists(image_path):
            print(f"File not found: {image_path}")
            sys.exit(1)
    else:
        image_path = "test_screenshot.jpg"
        print("No image provided — creating synthetic test image...")
        create_synthetic_test_image(image_path)

    print(f"\nAnalyzing: {image_path}")
    print("=" * 60)

    from screenshot_detection.detector import ScreenshotDetector

    detector = ScreenshotDetector(use_llm=True)
    result = detector.analyze_file(image_path)

    # Pretty print top-level summary
    print(f"\n{'='*60}")
    print(f"  RISK SCORE  : {result['risk_score']} / 100")
    print(f"  VERDICT     : {result['verdict']}")
    print(f"  RISK LEVEL  : {result['risk_level']}")
    print(f"{'='*60}")

    print("\n── Component Scores ──")
    for key, val in result["component_scores"].items():
        bar_len = int(val / 5)
        bar = "█" * bar_len + "░" * (20 - bar_len)
        print(f"  {key:<12} {bar}  {val:.1f}")

    print(f"\n── Recommendation ──")
    print(f"  {result['recommendation']}")

    if result.get("explanation"):
        print(f"\n── AI Explanation ──")
        print(f"  {result['explanation']}")

    print(f"\n── OCR Findings ──")
    ocr = result["details"]["ocr"]
    print(f"  Extracted {ocr['line_count']} text lines, avg confidence: {ocr['avg_confidence']:.2%}")
    if ocr.get("matched_scam_keywords"):
        print(f"  ⚠ Scam keywords: {ocr['matched_scam_keywords']}")
    if ocr.get("amounts_detected"):
        print(f"  Amounts found:  {ocr['amounts_detected']}")
    if ocr.get("upi_ids_detected"):
        print(f"  UPI IDs found:  {ocr['upi_ids_detected']}")

    print(f"\n── Forensic Findings ──")
    f = result["details"]["forensic"]
    print(f"  ELA score:     {f['ela']['ela_score']:.1f}")
    print(f"  Noise score:   {f['noise']['noise_inconsistency_score']:.1f}")
    print(f"  JPEG ghost:    {f['jpeg_ghost']['ghost_score']:.1f}  (double compressed: {f['jpeg_ghost']['double_compressed']})")

    print(f"\n── Metadata ──")
    m = result["details"]["metadata"]
    print(f"  Format: {m['image_format']}  Size: {m['image_size']}  Has EXIF: {m['has_exif']}")
    for flag in m.get("flags", []):
        print(f"  ⚠ {flag}")

    print("\nFull JSON saved to: analysis_result.json")
    with open("analysis_result.json", "w", encoding="utf-8") as f_out:
        json.dump(result, f_out, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
