@echo off
setlocal enabledelayedexpansion
title CyberGuardian - AI Cybersecurity
color 0A
cd /d "%~dp0"

echo.
echo  ==========================================
echo    CyberGuardian - Screenshot Detection
echo  ==========================================
echo.

:: ── Load GEMINI_API_KEY from .env ─────────────────────────────────────────
if exist ".env" (
    for /f "usebackq tokens=1,2 delims==" %%a in (".env") do (
        if /i "%%a"=="GEMINI_API_KEY" set "GEMINI_API_KEY=%%b"
    )
)

:: ── If key missing, ask once and save ─────────────────────────────────────
if "!GEMINI_API_KEY!"=="" (
    echo  [!] Gemini API key not found.
    set /p "GEMINI_API_KEY=  Paste your Gemini API Key: "
    echo GEMINI_API_KEY=!GEMINI_API_KEY!> .env
    echo  [OK] Saved to .env ^(won't ask again^)
    echo.
)

echo  [OK] Gemini API Key loaded.

:: ── Check Python ──────────────────────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [ERROR] Python not found. Install from https://python.org
    pause & exit /b 1
)

:: ── Create venv if not exists ─────────────────────────────────────────────
if not exist "venv\" (
    echo  [*] Creating virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo  [ERROR] Failed to create venv.
        pause & exit /b 1
    )
    echo  [OK] Virtual environment created.
)

:: ── Activate venv ─────────────────────────────────────────────────────────
call venv\Scripts\activate.bat

:: ── Install dependencies (first run only) ─────────────────────────────────
if not exist "venv\.deps_ok" (
    echo  [*] Installing dependencies ^(first time, takes ~2 min^)...
    echo.

    :: PaddlePaddle GPU for RTX 4050 CUDA 12.x
    pip install paddlepaddle-gpu==2.6.1.post120 ^
        -f https://www.paddlepaddle.org.cn/whl/windows/mkl/avx/stable.html -q

    if errorlevel 1 (
        echo  [!] GPU install failed, falling back to CPU PaddlePaddle...
        pip install paddlepaddle -q
    )

    pip install -r requirements.txt -q

    if errorlevel 1 (
        echo  [ERROR] Dependency install failed.
        pause & exit /b 1
    )

    type nul > venv\.deps_ok
    echo  [OK] Dependencies installed.
)

:: ── Check port 8000 not already in use ───────────────────────────────────
netstat -an | findstr ":8000 " | findstr "LISTENING" >nul 2>&1
if not errorlevel 1 (
    echo.
    echo  [!] Port 8000 already in use.
    echo      Kill the existing process or change PORT in this file.
    pause & exit /b 1
)

:: ── Open browser after 3 seconds ─────────────────────────────────────────
start "" cmd /c "timeout /t 3 >nul && start http://localhost:8000/docs"

:: ── Start FastAPI ─────────────────────────────────────────────────────────
echo.
echo  [OK] Starting server on http://localhost:8000
echo  [OK] API Docs will open in browser in 3 seconds...
echo.
echo  Press Ctrl+C to stop.
echo  ==========================================
echo.

python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload

echo.
echo  Server stopped.
pause
