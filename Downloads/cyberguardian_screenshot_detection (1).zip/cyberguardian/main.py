"""
CyberGuardian FastAPI Server
Run: uvicorn main:app --host 0.0.0.0 --port 8000 --reload
"""

import os
import base64
from contextlib import asynccontextmanager

from fastapi import FastAPI, UploadFile, File, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from screenshot_detection.detector import ScreenshotDetector


# ─── Startup / Shutdown ──────────────────────────────────────────────────────

detector: ScreenshotDetector | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global detector
    print("⚡ Loading CyberGuardian Screenshot Detector...")
    detector = ScreenshotDetector(use_llm=True)
    print("✅ Detector ready.")
    yield
    print("Shutting down.")


# ─── App ─────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="CyberGuardian API",
    description="AI-powered cybersecurity — Fake Screenshot Detection",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Routes ──────────────────────────────────────────────────────────────────

@app.get("/")
def root():
    return {"status": "CyberGuardian API running", "version": "1.0.0"}


@app.get("/health")
def health():
    return {"status": "ok", "detector_loaded": detector is not None}


# ── Route 1: File upload ─────────────────────────────────────────────────────

@app.post("/analyze/screenshot")
async def analyze_screenshot(file: UploadFile = File(...)):
    """
    Upload an image file (PNG/JPG/JPEG/WEBP) for fake screenshot analysis.
    Returns risk score, verdict, and detailed analysis.
    """
    if detector is None:
        raise HTTPException(503, "Detector not initialized")

    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(400, f"Expected image, got: {file.content_type}")

    # Read file
    contents = await file.read()
    if len(contents) == 0:
        raise HTTPException(400, "Empty file uploaded")

    MAX_SIZE_MB = 20
    if len(contents) > MAX_SIZE_MB * 1024 * 1024:
        raise HTTPException(413, f"File too large. Max {MAX_SIZE_MB}MB allowed.")

    try:
        # Determine suffix from filename
        suffix = ".png"
        if file.filename:
            ext = os.path.splitext(file.filename)[1].lower()
            if ext in (".jpg", ".jpeg", ".png", ".webp", ".bmp"):
                suffix = ext

        result = detector.analyze_bytes(contents, suffix=suffix)
        return JSONResponse(content=result)

    except Exception as e:
        raise HTTPException(500, f"Analysis failed: {str(e)}")


# ── Route 2: Base64 JSON (for Flutter) ──────────────────────────────────────

class Base64ImageRequest(BaseModel):
    image_base64: str        # base64-encoded image bytes
    file_extension: str = "png"   # jpg, png, webp

@app.post("/analyze/screenshot/base64")
async def analyze_screenshot_base64(body: Base64ImageRequest):
    """
    Accept base64-encoded image for analysis.
    Useful for Flutter/mobile clients where multipart is inconvenient.
    """
    if detector is None:
        raise HTTPException(503, "Detector not initialized")

    try:
        image_bytes = base64.b64decode(body.image_base64)
    except Exception:
        raise HTTPException(400, "Invalid base64 string")

    if len(image_bytes) == 0:
        raise HTTPException(400, "Empty image after decoding")

    suffix = f".{body.file_extension.lower().strip('.')}"

    try:
        result = detector.analyze_bytes(image_bytes, suffix=suffix)
        return JSONResponse(content=result)
    except Exception as e:
        raise HTTPException(500, f"Analysis failed: {str(e)}")


# ─── Entry point ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
