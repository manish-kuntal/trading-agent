# 🌑 Shadow App — Complete Setup Guide

## STEP 1 — Extract this ZIP
Extract to: `C:\Users\YourName\AndroidStudioProjects\Shadow\`

---

## STEP 2 — Open in Android Studio
1. Open Android Studio
2. File → Open
3. Select the `ShadowApp` folder you extracted
4. Wait for it to load (2-3 min)

---

## STEP 3 — Sync Gradle (ONE TIME)
When Android Studio opens, you'll see:
> "Gradle files have changed. Sync Now?"

Click **"Sync Now"** — this downloads all dependencies automatically.
Wait 3-5 minutes for first sync.

---

## STEP 4 — Fix themes.xml
Go to: `app/src/main/res/values/themes.xml`
Make sure it contains:
```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.Shadow" parent="android:Theme.Material.Light.NoActionBar" />
</resources>
```

---

## STEP 5 — Connect Your Phone
1. Enable USB Debugging on Realme Narzo 80 Pro:
   Settings → About Phone → tap Build Number 7 times
   Settings → Additional Settings → Developer Options → USB Debugging ON
2. Connect USB cable to laptop
3. Tap "Allow" on phone when it asks

---

## STEP 6 — Run the App
Click the green ▶ button in Android Studio
Select your phone → OK
Wait for install (~1 min)

---

## STEP 7 — Fix Battery (IMPORTANT!)
Settings → Battery → App Battery → Shadow → No Restrictions
(Without this, Android kills the GPS service when screen is off)

---

## STEP 8 — Test
1. Open Shadow app
2. Tap "Grant" for location permission
3. Select "Allow all the time"
4. Tap "Start"
5. Walk around → come back → see visits!

---

## CMD Commands (Advanced)

```cmd
# View live GPS logs
adb logcat -s Shadow.GPS

# Grant background location manually
adb shell pm grant com.shadow.app android.permission.ACCESS_BACKGROUND_LOCATION

# Check battery drain
adb shell dumpsys batterystats | findstr shadow

# Open database on phone
adb shell
run-as com.shadow.app
cd databases
sqlite3 shadow.db
.tables
SELECT * FROM location_points ORDER BY timestamp DESC LIMIT 5;
SELECT * FROM visits ORDER BY startTime DESC LIMIT 5;
```

---

## File Structure
```
ShadowApp/
├── app/
│   ├── build.gradle              ← All dependencies
│   └── src/main/
│       ├── AndroidManifest.xml   ← Permissions + Service
│       ├── res/values/
│       │   ├── themes.xml        ← App theme
│       │   └── strings.xml
│       └── java/com/shadow/app/
│           ├── ShadowApp.kt              ← App entry point
│           ├── data/db/
│           │   ├── AppDatabase.kt        ← SQLite database
│           │   ├── entity/
│           │   │   ├── LocationEntity.kt ← GPS point table
│           │   │   └── VisitEntity.kt    ← Visit/stay table
│           │   └── dao/
│           │       ├── LocationDao.kt    ← DB queries
│           │       └── VisitDao.kt
│           ├── data/repository/
│           │   └── LocationRepository.kt ← Data layer
│           ├── service/
│           │   └── LocationTrackingService.kt ← GPS service
│           ├── util/
│           │   ├── LocationUtils.kt      ← GPS math
│           │   └── StayDetector.kt       ← Visit detection
│           └── ui/
│               ├── MainActivity.kt       ← Main screen
│               ├── theme/Theme.kt        ← Colors/style
│               ├── viewmodel/TimelineViewModel.kt
│               └── screens/MainScreen.kt ← UI components
```

---

## What's Built (Week 1)
✅ GPS tracking with adaptive sampling
✅ Battery-smart (2 min intervals when stationary)
✅ Cold-start fix protection
✅ SQLite database with Room
✅ Real-time visit/stay detection
✅ Timeline UI with day navigation
✅ Visit cards with duration
✅ Live visit indicator
✅ Data pruning (7 days raw GPS)
