@echo off
echo ============================================
echo   SHADOW APP - Dependency Installer
echo   Run this ONCE from your project folder
echo ============================================

echo.
echo [1/4] Checking Java...
java -version
if errorlevel 1 (
    echo ERROR: Java not found! Install JDK 17 from https://adoptium.net
    pause
    exit /b 1
)

echo.
echo [2/4] Checking Android Studio Gradle...
if exist gradlew.bat (
    echo Found gradlew.bat - good!
) else (
    echo WARNING: gradlew.bat not found - run from project root folder
)

echo.
echo [3/4] Downloading all dependencies via Gradle...
call gradlew.bat dependencies --no-daemon

echo.
echo [4/4] Building the project...
call gradlew.bat assembleDebug --no-daemon

echo.
echo ============================================
if errorlevel 1 (
    echo BUILD FAILED - Check errors above
    echo Common fix: File - Sync Project with Gradle Files
) else (
    echo BUILD SUCCESS! APK is in:
    echo app/build/outputs/apk/debug/app-debug.apk
)
echo ============================================
pause
