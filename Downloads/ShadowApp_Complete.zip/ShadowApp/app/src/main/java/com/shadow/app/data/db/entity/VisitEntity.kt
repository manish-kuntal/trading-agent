package com.shadow.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * TABLE: visits
 * A "visit" = user stayed at one place for more than 5 minutes.
 * Derived from raw location_points by StayDetector algorithm.
 *
 * endTime = null means user is CURRENTLY at this place (active visit).
 */
@Entity(
    tableName = "visits",
    indices = [
        Index(value = ["startTime", "endTime"]),
        Index(value = ["latitude", "longitude"])
    ]
)
data class VisitEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val startTime: Long,
    val endTime: Long? = null,          // null = currently here (live visit)
    val latitude: Double,               // cluster center latitude
    val longitude: Double,              // cluster center longitude
    val accuracyMeters: Float = 50f,
    val placeName: String? = null,      // "Home", "College", "McDonald's" etc
    val placeType: String = "unknown",  // home / work / transit / unknown
    val durationSeconds: Long = 0,
    val pointCount: Int = 0             // how many GPS fixes in this visit
)
