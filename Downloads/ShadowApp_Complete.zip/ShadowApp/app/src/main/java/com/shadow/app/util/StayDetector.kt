package com.shadow.app.util

import com.shadow.app.data.db.entity.LocationEntity
import com.shadow.app.data.db.entity.VisitEntity

/**
 * ALGORITHM: Stay Detection
 *
 * Converts raw GPS points → meaningful "visits" (places user stayed > 5 min).
 *
 * How it works:
 *  1. Filter out bad fixes (accuracy > 50m) and travelling points (speed > 2 m/s)
 *  2. Group consecutive points that are within cluster radius of the anchor point
 *  3. If group duration > 5 minutes → it's a real visit → save it
 *  4. Move to next group when user leaves the radius
 *
 * GPS Expert improvements over naive 100m-fixed-radius:
 *  ✓ Dynamic radius (2× accuracy) → no false splits in cities
 *  ✓ Speed filter → no false visits while driving
 *  ✓ Weighted centroid → more precise visit center
 *  ✓ Cold-start discard → no wildly wrong first fix
 */
object StayDetector {

    private const val MIN_STAY_MS = 5 * 60 * 1000L   // 5 minutes minimum for a real visit
    private const val MIN_POINTS = 2                  // need at least 2 fixes to confirm

    /**
     * Process a list of raw GPS points and return completed visits.
     * Call this on day's worth of data to build the timeline.
     */
    fun detectVisits(points: List<LocationEntity>): List<VisitEntity> {
        if (points.size < MIN_POINTS) return emptyList()

        // Step 1: Filter unreliable and travelling points
        val reliable = points.filter { p ->
            LocationUtils.isFixReliable(p.accuracyMeters) &&
            !LocationUtils.isTravelling(p.speedMps)
        }
        if (reliable.size < MIN_POINTS) return emptyList()

        val visits = mutableListOf<VisitEntity>()
        var groupStart = 0
        var i = 1

        while (i < reliable.size) {
            val anchor = reliable[groupStart]
            val current = reliable[i]

            // Dynamic radius based on worst accuracy in comparison
            val radius = LocationUtils.getClusterRadiusMeters(
                maxOf(anchor.accuracyMeters, current.accuracyMeters)
            )

            val distance = LocationUtils.distanceMeters(
                anchor.latitude, anchor.longitude,
                current.latitude, current.longitude
            )

            if (distance > radius) {
                // User moved outside cluster — evaluate this group
                val group = reliable.subList(groupStart, i)
                val duration = reliable[i - 1].timestamp - anchor.timestamp

                if (duration >= MIN_STAY_MS && group.size >= MIN_POINTS) {
                    visits.add(buildVisit(group, endTime = current.timestamp))
                }
                groupStart = i  // start new group
            }
            i++
        }
        return visits
    }

    /**
     * Real-time check: has user moved away from the current active visit?
     * Called every GPS fix by the foreground service.
     */
    fun hasUserLeftVisit(newPoint: LocationEntity, activeVisit: VisitEntity): Boolean {
        if (!LocationUtils.isFixReliable(newPoint.accuracyMeters)) return false
        val radius = LocationUtils.getClusterRadiusMeters(
            maxOf(newPoint.accuracyMeters, activeVisit.accuracyMeters)
        )
        val distance = LocationUtils.distanceMeters(
            activeVisit.latitude, activeVisit.longitude,
            newPoint.latitude, newPoint.longitude
        )
        return distance > radius
    }

    // Build a VisitEntity from a cluster of GPS points
    private fun buildVisit(group: List<LocationEntity>, endTime: Long): VisitEntity {
        val weighted = group.map { Triple(it.latitude, it.longitude, it.accuracyMeters) }
        val (centerLat, centerLon) = LocationUtils.weightedCentroid(weighted)
        val avgAccuracy = group.map { it.accuracyMeters }.average().toFloat()

        return VisitEntity(
            startTime = group.first().timestamp,
            endTime = endTime,
            latitude = centerLat,
            longitude = centerLon,
            accuracyMeters = avgAccuracy,
            durationSeconds = (endTime - group.first().timestamp) / 1000,
            pointCount = group.size,
            placeName = null,       // filled later by reverse geocoder
            placeType = "unknown"
        )
    }
}
