package com.shadow.app.data.db.dao

import androidx.room.*
import com.shadow.app.data.db.entity.LocationEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO = Data Access Object
 * All database operations for the location_points table.
 * Flow = reactive — UI auto-updates when data changes
 * suspend = runs on background thread (coroutine)
 */
@Dao
interface LocationDao {

    // ── Save ──────────────────────────────────────────────────────────────
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(location: LocationEntity): Long

    // ── Read latest fix ───────────────────────────────────────────────────
    @Query("SELECT * FROM location_points ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatest(): LocationEntity?

    // ── Read by date range (for timeline) ────────────────────────────────
    @Query("SELECT * FROM location_points WHERE timestamp BETWEEN :startMs AND :endMs ORDER BY timestamp ASC")
    suspend fun getByTimeRange(startMs: Long, endMs: Long): List<LocationEntity>

    // ── Reactive stream for UI ────────────────────────────────────────────
    @Query("SELECT * FROM location_points WHERE timestamp BETWEEN :startMs AND :endMs ORDER BY timestamp ASC")
    fun observeByTimeRange(startMs: Long, endMs: Long): Flow<List<LocationEntity>>

    @Query("SELECT * FROM location_points ORDER BY timestamp DESC LIMIT :limit")
    fun observeRecent(limit: Int = 100): Flow<List<LocationEntity>>

    // ── Cleanup old raw data (keep only 7 days) ───────────────────────────
    @Query("DELETE FROM location_points WHERE timestamp < :beforeMs")
    suspend fun deleteOlderThan(beforeMs: Long): Int
}
