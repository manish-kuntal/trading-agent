package com.shadow.app.util

import kotlin.math.*

/**
 * GPS Expert utility functions.
 *
 * KEY RULES:
 * 1. Cold-start discard  — first GPS fix is often very inaccurate. Drop if accuracy > 50m.
 * 2. Dynamic cluster radius — radius = 2x GPS accuracy (NOT fixed 100m).
 * 3. Speed-adaptive sampling — slow GPS when stationary saves battery.
 * 4. Speed filter — skip stay detection if user is travelling (>2 m/s).
 */
object LocationUtils {

    // ── Accuracy filter ───────────────────────────────────────────────────

    /** Realme Narzo 80 Pro cold-start fix can be 100-300m off — discard above 50m */
    private const val MAX_ACCURATE_M = 50f

    fun isFixReliable(accuracyMeters: Float): Boolean = accuracyMeters <= MAX_ACCURATE_M

    // ── Distance (Haversine formula) ──────────────────────────────────────

    /**
     * Great-circle distance between two GPS points in metres.
     * More accurate than simple Euclidean for distances > 1km.
     */
    fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val R = 6_371_000.0   // Earth radius in metres
        val φ1 = Math.toRadians(lat1)
        val φ2 = Math.toRadians(lat2)
        val Δφ = Math.toRadians(lat2 - lat1)
        val Δλ = Math.toRadians(lon2 - lon1)
        val a = sin(Δφ / 2).pow(2) + cos(φ1) * cos(φ2) * sin(Δλ / 2).pow(2)
        return R * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    // ── Adaptive sampling ─────────────────────────────────────────────────

    /**
     * GPS sampling interval based on speed:
     *   Stationary (<0.5 m/s) → 2 minutes   ← saves huge battery
     *   Walking    (<1.5 m/s) → 30 seconds
     *   Cycling    (<8.0 m/s) → 10 seconds
     *   Vehicle    (≥8.0 m/s) →  5 seconds
     */
    fun getSamplingIntervalMs(speedMps: Float): Long = when {
        speedMps < 0.5f -> 120_000L   // 2 min
        speedMps < 1.5f ->  30_000L   // 30 sec
        speedMps < 8.0f ->  10_000L   // 10 sec
        else            ->   5_000L   //  5 sec
    }

    fun isStationary(speedMps: Float): Boolean = speedMps < 0.5f

    // ── Cluster radius ────────────────────────────────────────────────────

    /**
     * Dynamic radius = 2× worst GPS accuracy in the group.
     * Minimum 50m to handle urban GPS jitter.
     *
     * Example: accuracy=30m → radius=60m (covers the entire jitter range)
     */
    fun getClusterRadiusMeters(worstAccuracyM: Float): Double =
        maxOf(50.0, worstAccuracyM * 2.0)

    /** User is travelling — skip stay detection */
    fun isTravelling(speedMps: Float): Boolean = speedMps > 2.0f

    // ── Weighted centroid ─────────────────────────────────────────────────

    /**
     * More accurate GPS fixes (low accuracy number) get more weight.
     * Returns (latitude, longitude) of the cluster center.
     */
    fun weightedCentroid(points: List<Triple<Double, Double, Float>>): Pair<Double, Double> {
        if (points.isEmpty()) return 0.0 to 0.0
        var sumLat = 0.0; var sumLon = 0.0; var sumW = 0.0
        for ((lat, lon, acc) in points) {
            val w = if (acc > 0) 1.0 / acc else 1.0
            sumLat += lat * w; sumLon += lon * w; sumW += w
        }
        return (sumLat / sumW) to (sumLon / sumW)
    }
}
