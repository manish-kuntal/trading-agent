package com.shadow.app.data.db.dao

import androidx.room.*
import com.shadow.app.data.db.entity.VisitEntity
import kotlinx.coroutines.flow.Flow

/**
 * DAO for the visits table.
 * Visits are permanent — only raw GPS points get pruned.
 */
@Dao
interface VisitDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(visit: VisitEntity): Long

    @Update
    suspend fun update(visit: VisitEntity)

    // Currently active visit (endTime IS NULL = user still here)
    @Query("SELECT * FROM visits WHERE endTime IS NULL ORDER BY startTime DESC LIMIT 1")
    suspend fun getActiveVisit(): VisitEntity?

    @Query("SELECT * FROM visits WHERE id = :id")
    suspend fun getById(id: Long): VisitEntity?

    // All visits for a specific day — used in timeline UI
    @Query("SELECT * FROM visits WHERE startTime BETWEEN :startMs AND :endMs ORDER BY startTime ASC")
    fun observeByTimeRange(startMs: Long, endMs: Long): Flow<List<VisitEntity>>

    // Recent visits feed
    @Query("SELECT * FROM visits ORDER BY startTime DESC LIMIT :limit")
    fun observeRecent(limit: Int = 30): Flow<List<VisitEntity>>

    // Which days have visit data (for calendar)
    @Query("SELECT DISTINCT date(startTime / 1000, 'unixepoch', 'localtime') AS day FROM visits ORDER BY day DESC")
    suspend fun getDaysWithVisits(): List<String>

    // Top places summary (for insights screen)
    @Query("""
        SELECT placeName, SUM(durationSeconds) AS totalSec, COUNT(*) AS visitCount
        FROM visits
        WHERE startTime > :sinceMs AND placeName IS NOT NULL
        GROUP BY placeName
        ORDER BY totalSec DESC
        LIMIT 10
    """)
    suspend fun getTopPlacesSince(sinceMs: Long): List<PlaceSummary>
}

/** Lightweight data class for place insights — not a full entity */
data class PlaceSummary(
    val placeName: String,
    val totalSec: Long,
    val visitCount: Int
)
