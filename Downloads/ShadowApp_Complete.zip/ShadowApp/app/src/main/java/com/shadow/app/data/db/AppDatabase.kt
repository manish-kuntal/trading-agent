package com.shadow.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.shadow.app.data.db.dao.LocationDao
import com.shadow.app.data.db.dao.VisitDao
import com.shadow.app.data.db.entity.LocationEntity
import com.shadow.app.data.db.entity.VisitEntity

/**
 * Main Room database — single instance (singleton pattern).
 * File stored at: /data/data/com.shadow.app/databases/shadow.db
 *
 * To add encryption later: replace Room.databaseBuilder with SQLCipher builder.
 * To add more tables: add entity to @Database list + create DAO + abstract fun.
 */
@Database(
    entities = [LocationEntity::class, VisitEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun locationDao(): LocationDao
    abstract fun visitDao(): VisitDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "shadow.db"     // database file name
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
