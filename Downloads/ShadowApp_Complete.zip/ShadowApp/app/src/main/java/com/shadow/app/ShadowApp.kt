package com.shadow.app

import android.app.Application

/**
 * Application class — entry point of the app.
 * Declared in AndroidManifest as android:name=".ShadowApp"
 */
class ShadowApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Future: init WorkManager, crash reporting, etc.
    }
}
