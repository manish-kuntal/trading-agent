package com.shadow.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary          = Color(0xFF4CAF50),
    onPrimary        = Color(0xFF003907),
    primaryContainer = Color(0xFF00531A),
    secondary        = Color(0xFF64B5F6),
    background       = Color(0xFF101010),
    surface          = Color(0xFF1C1C1C),
    onSurface        = Color(0xFFE0E0E0)
)

private val LightColors = lightColorScheme(
    primary          = Color(0xFF2E7D32),
    onPrimary        = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFC8F5C8),
    secondary        = Color(0xFF1565C0),
    background       = Color(0xFFF5F5F5),
    surface          = Color(0xFFFFFFFF),
    onSurface        = Color(0xFF1A1A1A)
)

@Composable
fun ShadowTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography  = Typography(),
        content     = content
    )
}
