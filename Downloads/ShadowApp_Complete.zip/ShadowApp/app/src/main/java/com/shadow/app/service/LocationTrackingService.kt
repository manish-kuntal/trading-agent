package com.shadow.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.shadow.app.data.db.AppDatabase
import com.shadow.app.data.db.entity.LocationEntity
import com.shadow.app.data.db.entity.VisitEntity
import com.shadow.app.data.repository.LocationRepository
import com.shadow.app.ui.MainActivity
import com.shadow.app.util.LocationUtils
import com.shadow.app.util.StayDetector
import kotlinx.coroutines.*

/**
 * CORE SERVICE: Runs in the foreground so Android doesn't kill it.
 *
 * What it does every GPS fix:
 *  1. Discard if accuracy > 50m (cold-start protection)
 *  2. Save raw fix to location_points table
 *  3. Adjust GPS sampling interval based on speed (adaptive)
 *  4. Update active visit (open/close based on movement)
 *
 * START: startForegroundService(LocationTrackingService.startIntent(context))
 * STOP:  startService(LocationTrackingService.stopIntent(context))
 */
class LocationTrackingService : Service() {

    companion object {
        const val TAG = "Shadow.GPS"
        const val CHANNEL_ID = "shadow_tracking_channel"
        const val NOTIF_ID = 1001

        const val ACTION_START = "com.shadow.START"
        const val ACTION_STOP  = "com.shadow.STOP"

        fun startIntent(ctx: Context) =
            Intent(ctx, LocationTrackingService::class.java).apply { action = ACTION_START }

        fun stopIntent(ctx: Context) =
            Intent(ctx, LocationTrackingService::class.java).apply { action = ACTION_STOP }
    }

    private lateinit var fusedClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private lateinit var repository: LocationRepository
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // Adaptive sampling — starts at 30s, changes based on speed
    private var currentIntervalMs = 30_000L
    private var fixCount = 0

    // Active visit state
    private var activeVisitId: Long? = null
    private var activeVisitStartMs: Long = 0
    private var activeVisitLat: Double = 0.0
    private var activeVisitLon: Double = 0.0
    private var activeVisitAcc: Float = 50f
    private var activeVisitPoints = 0
    private val MIN_VISIT_MS = 5 * 60 * 1000L  // 5 minutes to declare a visit

    // ── Lifecycle ─────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        fusedClient = LocationServices.getFusedLocationProviderClient(this)
        val db = AppDatabase.getInstance(this)
        repository = LocationRepository(db.locationDao(), db.visitDao())
        createNotificationChannel()
        buildLocationCallback()
        Log.d(TAG, "Service created ✓")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startTracking()
            ACTION_STOP  -> stopTracking()
        }
        return START_STICKY   // Android auto-restarts this service if killed
    }

    override fun onDestroy() {
        super.onDestroy()
        fusedClient.removeLocationUpdates(locationCallback)
        serviceScope.cancel()
        Log.d(TAG, "Service destroyed")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Start / Stop ──────────────────────────────────────────────────────

    private fun startTracking() {
        Log.i(TAG, "▶ Tracking started")
        // Must call startForeground IMMEDIATELY or Android kills the service
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, buildNotification("📍 Recording your shadow..."),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIF_ID, buildNotification("📍 Recording your shadow..."))
        }
        requestLocationUpdates(currentIntervalMs)
    }

    private fun stopTracking() {
        Log.i(TAG, "■ Tracking stopped")
        fusedClient.removeLocationUpdates(locationCallback)
        serviceScope.launch { closeActiveVisit(System.currentTimeMillis()) }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ── GPS Callback ──────────────────────────────────────────────────────

    @Suppress("MissingPermission")
    private fun requestLocationUpdates(intervalMs: Long) {
        val request = LocationRequest.Builder(
            Priority.PRIORITY_BALANCED_POWER_ACCURACY,
            intervalMs
        )
            .setMinUpdateIntervalMillis(5_000L)
            .setMaxUpdateDelayMillis(intervalMs * 2)
            .build()

        try {
            fusedClient.requestLocationUpdates(request, locationCallback, Looper.getMainLooper())
            Log.d(TAG, "Updates: every ${intervalMs / 1000}s")
        } catch (e: SecurityException) {
            Log.e(TAG, "Permission missing: ${e.message}")
            stopSelf()
        }
    }

    private fun buildLocationCallback() {
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                fixCount++

                // ── RULE 1: Discard inaccurate fixes (cold-start protection) ──
                if (!LocationUtils.isFixReliable(loc.accuracy)) {
                    Log.d(TAG, "Fix #$fixCount DISCARDED — accuracy=${loc.accuracy}m > 50m")
                    return
                }

                val entity = LocationEntity(
                    timestamp      = loc.time,
                    latitude       = loc.latitude,
                    longitude      = loc.longitude,
                    accuracyMeters = loc.accuracy,
                    speedMps       = if (loc.hasSpeed())    loc.speed    else 0f,
                    heading        = if (loc.hasBearing())  loc.bearing  else 0f,
                    altitude       = if (loc.hasAltitude()) loc.altitude else 0.0,
                    batteryLevel   = getBatteryLevel()
                )

                serviceScope.launch {
                    // Save to database
                    repository.saveLocation(entity)
                    Log.v(TAG, "Fix #$fixCount saved: ${entity.latitude}, ${entity.longitude} ±${entity.accuracyMeters}m speed=${entity.speedMps}m/s")

                    // ── RULE 2: Adaptive sampling based on speed ───────────
                    val newInterval = LocationUtils.getSamplingIntervalMs(entity.speedMps)
                    if (newInterval != currentIntervalMs) {
                        currentIntervalMs = newInterval
                        Log.d(TAG, "⚡ Sampling → ${newInterval / 1000}s (speed=${entity.speedMps}m/s)")
                        withContext(Dispatchers.Main) {
                            fusedClient.removeLocationUpdates(locationCallback)
                            requestLocationUpdates(newInterval)
                        }
                    }

                    // ── Real-time visit tracking ───────────────────────────
                    handleVisitTracking(entity)
                }
            }
        }
    }

    // ── Visit tracking ────────────────────────────────────────────────────

    private suspend fun handleVisitTracking(point: LocationEntity) {
        // If user is travelling — close any open visit
        if (LocationUtils.isTravelling(point.speedMps)) {
            if (activeVisitId != null) closeActiveVisit(point.timestamp)
            resetVisitState()
            return
        }

        if (activeVisitId == null) {
            // Accumulating points — not yet a confirmed visit
            if (activeVisitPoints == 0) {
                activeVisitStartMs = point.timestamp
                activeVisitLat = point.latitude
                activeVisitLon = point.longitude
                activeVisitAcc = point.accuracyMeters
                activeVisitPoints = 1
            } else {
                val dist = LocationUtils.distanceMeters(
                    activeVisitLat, activeVisitLon,
                    point.latitude, point.longitude
                )
                val radius = LocationUtils.getClusterRadiusMeters(
                    maxOf(activeVisitAcc, point.accuracyMeters)
                )

                if (dist <= radius) {
                    activeVisitPoints++
                    val elapsed = point.timestamp - activeVisitStartMs
                    // After 5 minutes stationary → open a visit in DB
                    if (elapsed >= MIN_VISIT_MS) {
                        val visit = VisitEntity(
                            startTime      = activeVisitStartMs,
                            endTime        = null,
                            latitude       = activeVisitLat,
                            longitude      = activeVisitLon,
                            accuracyMeters = activeVisitAcc,
                            pointCount     = activeVisitPoints
                        )
                        activeVisitId = repository.saveVisit(visit)
                        Log.i(TAG, "📍 Visit OPENED id=$activeVisitId at (${activeVisitLat}, ${activeVisitLon})")
                    }
                } else {
                    // Moved before visit confirmed — reset and start fresh
                    Log.d(TAG, "Moved before visit confirmed (${dist}m > ${radius}m) — resetting")
                    resetVisitState()
                    activeVisitStartMs = point.timestamp
                    activeVisitLat = point.latitude
                    activeVisitLon = point.longitude
                    activeVisitAcc = point.accuracyMeters
                    activeVisitPoints = 1
                }
            }
        } else {
            // Active visit exists — check if user has left
            val fakeVisit = VisitEntity(
                id = activeVisitId!!, startTime = activeVisitStartMs,
                latitude = activeVisitLat, longitude = activeVisitLon,
                accuracyMeters = activeVisitAcc
            )
            if (StayDetector.hasUserLeftVisit(point, fakeVisit)) {
                Log.i(TAG, "🚶 User left visit id=$activeVisitId")
                closeActiveVisit(point.timestamp)
            } else {
                activeVisitPoints++
            }
        }
    }

    private suspend fun closeActiveVisit(endTime: Long) {
        val id = activeVisitId ?: return
        val updated = VisitEntity(
            id              = id,
            startTime       = activeVisitStartMs,
            endTime         = endTime,
            latitude        = activeVisitLat,
            longitude       = activeVisitLon,
            accuracyMeters  = activeVisitAcc,
            durationSeconds = (endTime - activeVisitStartMs) / 1000,
            pointCount      = activeVisitPoints
        )
        repository.updateVisit(updated)
        Log.i(TAG, "✅ Visit id=$id CLOSED — duration=${updated.durationSeconds}s")
        resetVisitState()
    }

    private fun resetVisitState() {
        activeVisitId = null; activeVisitPoints = 0
        activeVisitStartMs = 0; activeVisitLat = 0.0
        activeVisitLon = 0.0; activeVisitAcc = 50f
    }

    // ── Notification ──────────────────────────────────────────────────────

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 1, stopIntent(this), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Shadow")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Location Tracking",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Shadow GPS tracking"
            setShowBadge(false)
        }
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    // ── Battery level ─────────────────────────────────────────────────────

    private fun getBatteryLevel(): Int = try {
        (getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    } catch (e: Exception) { -1 }
}
