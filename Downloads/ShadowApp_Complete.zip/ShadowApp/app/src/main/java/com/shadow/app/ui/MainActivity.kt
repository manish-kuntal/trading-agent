package com.shadow.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import com.shadow.app.service.LocationTrackingService
import com.shadow.app.ui.screens.MainScreen
import com.shadow.app.ui.theme.ShadowTheme

class MainActivity : ComponentActivity() {

    // Permissions needed
    private val permissions = buildList {
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Step 1: Request foreground location
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            // Step 2: On Android 11+ request background location SEPARATELY
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                backgroundPermLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            }
        }
    }

    // Step 2: Background location (shown AFTER foreground is granted)
    private val backgroundPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        android.util.Log.d("Shadow", "Background location: $granted")
    }

    private var isTracking by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Auto-request permissions on first launch
        if (!checkPermissions()) {
            permissionLauncher.launch(permissions.toTypedArray())
        }

        setContent {
            ShadowTheme {
                var permGranted by remember { mutableStateOf(checkPermissions()) }

                MainScreen(
                    isTracking          = isTracking,
                    permissionsGranted  = permGranted,
                    onRequestPermissions = {
                        permissionLauncher.launch(permissions.toTypedArray())
                        permGranted = checkPermissions()
                    },
                    onStartTracking = {
                        startForegroundService(LocationTrackingService.startIntent(this))
                        isTracking = true
                    },
                    onStopTracking = {
                        startService(LocationTrackingService.stopIntent(this))
                        isTracking = false
                    },
                    onOpenSettings = {
                        startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", packageName, null)
                            }
                        )
                    }
                )
            }
        }
    }

    private fun checkPermissions(): Boolean =
        permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
}
