package com.shadow.app.data.repository

import com.shadow.app.data.db.dao.LocationDao
import com.shadow.app.data.db.dao.PlaceSummary
import com.shadow.app.data.db.dao.VisitDao
import com.shadow.app.data.db.entity.LocationEntity
import com.shadow.app.data.db.entity.VisitEntity
import kotlinx.coroutines.flow.Flow
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Repository = single source of truth for all data.
 * ViewModel talks to Repository. Repository talks to DAOs.
 * This keeps business logic separate from database code.
 */
class LocationRepository(
    private val locationDao: LocationDao,
    private val visitDao: VisitDao
) {

    // ── Location points ───────────────────────────────────────────────────

    suspend fun saveLocation(entity: LocationEntity): Long =
        locationDao.insert(entity)

    suspend fun getLatestLocation(): LocationEntity? =
        locationDao.getLatest()

    fun observeLocationsForDay(dayStartMs: Long): Flow<List<LocationEntity>> =
        locationDao.observeByTimeRange(dayStartMs, dayStartMs + DAY_MS)

    // ── Visits ────────────────────────────────────────────────────────────

    suspend fun saveVisit(visit: VisitEntity): Long =
        visitDao.insert(visit)

    suspend fun updateVisit(visit: VisitEntity) =
        visitDao.update(visit)

    suspend fun getActiveVisit(): VisitEntity? =
        visitDao.getActiveVisit()

    fun observeVisitsForDay(dayStartMs: Long): Flow<List<VisitEntity>> =
        visitDao.observeByTimeRange(dayStartMs, dayStartMs + DAY_MS)

    fun observeRecentVisits(limit: Int = 30): Flow<List<VisitEntity>> =
        visitDao.observeRecent(limit)

    suspend fun getDaysWithData(): List<String> =
        visitDao.getDaysWithVisits()

    // ── Insights ──────────────────────────────────────────────────────────

    suspend fun getTopPlacesLastDays(days: Int = 7): List<PlaceSummary> {
        val sinceMs = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(days.toLong())
        return visitDao.getTopPlacesSince(sinceMs)
    }

    // ── Maintenance (run via WorkManager weekly) ──────────────────────────

    suspend fun pruneRawGpsPoints(keepDays: Int = 7): Int {
        val cutoffMs = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(keepDays.toLong())
        return locationDao.deleteOlderThan(cutoffMs)
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    companion object {
        const val DAY_MS = 24 * 60 * 60 * 1000L

        /** Returns midnight 00:00:00 of today in local time as epoch milliseconds */
        fun todayStartMs(): Long = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
}
