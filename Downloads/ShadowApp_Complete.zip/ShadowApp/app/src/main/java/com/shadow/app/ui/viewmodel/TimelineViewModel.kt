package com.shadow.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shadow.app.data.db.AppDatabase
import com.shadow.app.data.db.entity.LocationEntity
import com.shadow.app.data.db.entity.VisitEntity
import com.shadow.app.data.repository.LocationRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * UI State — everything the screen needs to display
 */
data class TimelineUiState(
    val isLoading: Boolean = true,
    val selectedDayMs: Long = LocationRepository.todayStartMs(),
    val locations: List<LocationEntity> = emptyList(),
    val visits: List<VisitEntity> = emptyList(),
    val isTracking: Boolean = false
)

/**
 * ViewModel — survives screen rotation, manages data streams.
 * Screen observes uiState, calls action functions (selectDay, etc.)
 */
class TimelineViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.getInstance(app)
    private val repo = LocationRepository(db.locationDao(), db.visitDao())

    private val _uiState = MutableStateFlow(TimelineUiState())
    val uiState: StateFlow<TimelineUiState> = _uiState.asStateFlow()

    private val _selectedDay = MutableStateFlow(LocationRepository.todayStartMs())

    init {
        // Auto-update UI whenever selected day changes
        viewModelScope.launch {
            _selectedDay.collectLatest { dayMs ->
                _uiState.update { it.copy(isLoading = true, selectedDayMs = dayMs) }

                // Subscribe to GPS points for this day
                launch {
                    repo.observeLocationsForDay(dayMs).collect { locs ->
                        _uiState.update { it.copy(locations = locs, isLoading = false) }
                    }
                }
                // Subscribe to visits for this day
                launch {
                    repo.observeVisitsForDay(dayMs).collect { visits ->
                        _uiState.update { it.copy(visits = visits) }
                    }
                }
            }
        }
    }

    // ── Actions (called by UI) ────────────────────────────────────────────

    fun goToPreviousDay() { _selectedDay.value -= LocationRepository.DAY_MS }

    fun goToNextDay() {
        val next = _selectedDay.value + LocationRepository.DAY_MS
        if (next <= System.currentTimeMillis()) _selectedDay.value = next
    }

    fun selectToday() { _selectedDay.value = LocationRepository.todayStartMs() }

    fun setTracking(active: Boolean) { _uiState.update { it.copy(isTracking = active) } }
}
