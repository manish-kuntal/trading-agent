package com.shadow.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shadow.app.data.db.entity.VisitEntity
import com.shadow.app.ui.viewmodel.TimelineViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MainScreen(
    isTracking: Boolean,
    permissionsGranted: Boolean,
    onRequestPermissions: () -> Unit,
    onStartTracking: () -> Unit,
    onStopTracking: () -> Unit,
    onOpenSettings: () -> Unit,
    vm: TimelineViewModel = viewModel()
) {
    val state by vm.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(12.dp))

        // App title
        Text(
            "🌑 Shadow",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Your life, recorded silently.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(12.dp))

        // Permission warning
        if (!permissionsGranted) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        "⚠️ Location permission needed",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onRequestPermissions) { Text("Grant") }
                        OutlinedButton(onClick = onOpenSettings) { Text("Settings") }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        // Tracking control card
        Card(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        if (isTracking) "🟢 Active" else "⚫ Inactive",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "${state.locations.size} GPS points · ${state.visits.size} visits",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Button(
                    onClick = if (isTracking) onStopTracking else onStartTracking,
                    enabled = permissionsGranted,
                    colors = if (isTracking)
                        ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    else ButtonDefaults.buttonColors()
                ) {
                    Text(if (isTracking) "Stop" else "Start")
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Day navigation
        val isToday = run {
            val c = Calendar.getInstance()
            val s = Calendar.getInstance().apply { timeInMillis = state.selectedDayMs }
            c.get(Calendar.DAY_OF_YEAR) == s.get(Calendar.DAY_OF_YEAR) &&
            c.get(Calendar.YEAR) == s.get(Calendar.YEAR)
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.goToPreviousDay() }) {
                Text("◀", style = MaterialTheme.typography.titleLarge)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    SimpleDateFormat("EEE, d MMM", Locale.getDefault())
                        .format(Date(state.selectedDayMs)),
                    style = MaterialTheme.typography.titleMedium
                )
                if (isToday) Text(
                    "Today",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!isToday) TextButton(onClick = { vm.selectToday() }) { Text("Today") }
                IconButton(onClick = { vm.goToNextDay() }, enabled = !isToday) {
                    Text("▶", style = MaterialTheme.typography.titleLarge)
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Timeline content
        when {
            state.isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            state.visits.isEmpty() && state.locations.isEmpty() ->
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📍", style = MaterialTheme.typography.displayLarge)
                        Spacer(Modifier.height(8.dp))
                        Text("No data for this day", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Start tracking to record your journey",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            else -> LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                if (state.visits.isNotEmpty()) {
                    item {
                        Text(
                            "Places visited",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    items(state.visits, key = { it.id }) { visit ->
                        VisitCard(visit)
                    }
                }
                if (state.locations.isNotEmpty()) {
                    item {
                        Spacer(Modifier.height(4.dp))
                        HorizontalDivider()
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "${state.locations.size} raw GPS points logged today",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VisitCard(visit: VisitEntity) {
    val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Time column
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.width(52.dp)
            ) {
                Text(fmt.format(Date(visit.startTime)), style = MaterialTheme.typography.labelLarge)
                Text("│", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    visit.endTime?.let { fmt.format(Date(it)) } ?: "now",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (visit.endTime == null)
                        MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.width(12.dp))

            // Place info
            Column(Modifier.weight(1f)) {
                Text(
                    visit.placeName ?: "%.5f, %.5f".format(visit.latitude, visit.longitude),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    buildString {
                        append(formatDuration(visit.durationSeconds))
                        append(" · ${visit.pointCount} fixes")
                        if (visit.endTime == null) append(" · LIVE")
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Live badge
            if (visit.endTime == null) {
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        "LIVE",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

private fun formatDuration(sec: Long): String = when {
    sec < 60   -> "${sec}s"
    sec < 3600 -> "${sec / 60}m"
    else       -> "${sec / 3600}h ${(sec % 3600) / 60}m"
}
