package com.shadow.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * TABLE: location_points
 * Stores every raw GPS fix from the Fused Location Provider.
 * Index on timestamp = fast date-range queries ("where was I on Tuesday?")
 */
@Entity(
    tableName = "location_points",
    indices = [Index(value = ["timestamp"])]
)
data class LocationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(), // epoch ms
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,      // GPS accuracy (metres) — lower = better
    val speedMps: Float = 0f,       // speed in metres/second
    val heading: Float = 0f,        // direction in degrees (0 = North)
    val altitude: Double = 0.0,     // metres above sea level
    val batteryLevel: Int = -1      // 0-100, -1 = unknown
)
