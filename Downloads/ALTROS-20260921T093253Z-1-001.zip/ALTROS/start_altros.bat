@echo off
set PYTHONIOENCODING=utf-8
title ALTROS — Starting...

echo.
echo  ================================================
echo   ALTROS — Autonomous Learning AI System
echo  ================================================
echo.

:: Start Ollama
echo [1/3] Starting Ollama...
start "" "ollama" serve
timeout /t 3 /nobreak >nul

:: Start ALTROS
echo [2/3] Starting ALTROS...
start "" cmd /k "cd /d C:\ALTROS && py -3.12 main.py"
timeout /t 5 /nobreak >nul

:: Start Ngrok
echo [3/3] Starting Ngrok tunnel...
start "" cmd /k "ngrok http 8000 --log=stdout > C:\ALTROS\ngrok.log 2>&1"
timeout /t 4 /nobreak >nul

:: Get URL and save it
echo Waiting for ngrok URL...
timeout /t 3 /nobreak >nul

:: Open URL finder page
echo.
echo  ================================================
echo   ALTROS is running!
echo   Open: http://localhost:4040 to see ngrok URL
echo   Or check: C:\ALTROS\ngrok.log
echo  ================================================
echo.

:: Open ngrok dashboard in browser
start "" "http://localhost:4040"

exit
