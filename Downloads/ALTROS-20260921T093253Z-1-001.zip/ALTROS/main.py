#!/usr/bin/env python3
# ============================================================
#  ALTROS — Main Entry Point v2.0
#  Now with: Thinking Engine + 3-Layer Memory + Autonomy
# ============================================================

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from core.memory import MemorySystem
from core.brain import Brain
from core.thinking import ThinkingEngine
from core.router import Router, ModuleManager

from modules.chat import ChatModule
from modules.knowledge import KnowledgeModule
from modules.voice import VoiceModule
from modules.wake_word import WakeWordModule
from modules.internet import InternetModule
from modules.pc_control import PCControlModule
from modules.server import ServerModule
from modules.autonomy import AutonomyModule
from modules.instagram import InstagramModule
from modules.gmail import GmailModule
from config import ASSISTANT_NAME, USER_NAME, MODULES_ENABLED, NGROK_AUTHTOKEN, SERVER_PORT


def boot():
    print(f"\n{'='*52}")
    print(f"  {ASSISTANT_NAME} v2.0 — Booting...")
    print(f"{'='*52}")

    # Core systems
    memory  = MemorySystem()
    brain   = Brain(memory)
    thinker = ThinkingEngine(brain)
    brain.set_thinking_engine(thinker)

    # Module manager
    mm = ModuleManager()
    print("\nLoading modules:")

    internet_mod  = InternetModule()
    pc_mod        = PCControlModule()
    knowledge_mod = KnowledgeModule()
    voice_mod     = VoiceModule()
    wake_word_mod = WakeWordModule()
    server_mod    = ServerModule()
    autonomy_mod  = AutonomyModule()
    instagram_mod = InstagramModule()
    gmail_mod     = GmailModule()

    mm.register(internet_mod)
    mm.register(pc_mod)
    mm.register(knowledge_mod)
    mm.register(voice_mod)
    mm.register(wake_word_mod)
    mm.register(autonomy_mod)
    mm.register(instagram_mod)
    mm.register(gmail_mod)
    mm.register(server_mod)
    mm.register(ChatModule())

    router = Router(brain, memory, mm)

    print()
    if brain.check_connection():
        print(f"  🧠 Ollama connected — model: {brain.model}")
    else:
        print(f"  ⚠️  Ollama not running. Run: ollama serve")

    active = mm.list_active()
    print(f"\n  Active modules: {', '.join(active)}")
    print(f"\n  Commands: help | exit | clear | memory | books | tasks | voice")
    print(f"{'='*52}\n")

    return memory, brain, router, knowledge_mod, voice_mod, wake_word_mod, server_mod, autonomy_mod


def show_help():
    print("""
COMMANDS:
  exit            — ALTROS band karo
  clear           — Session clear karo
  memory          — Profile dekho
  remember X Y    — Kuch yaad karwao
  books           — Knowledge base count
  tasks           — Pending tasks dekho
  voice           — Mic se baat karo (5 sec)
  voice 10        — 10 sec record
  help            — Ye menu
""")


def handle_command(user_input, memory, knowledge_mod, voice_mod, router, autonomy_mod):
    cmd = user_input.lower().strip()

    if cmd == "exit":
        print(f"\nALTROS: Chalte hain, {USER_NAME}. Take care! 👋\n")
        memory.clear_session()
        return True, True

    if cmd == "help":
        show_help()
        return True, False

    if cmd == "clear":
        memory.clear_session()
        print("ALTROS: Session clear. Fresh start.\n")
        return True, False

    if cmd == "memory":
        summary = memory.get_profile_summary()
        print(f"\nALTROS:\n{summary if summary else 'Abhi kuch yaad nahi.'}\n")
        return True, False

    if cmd == "tasks":
        tasks = autonomy_mod.get_pending_tasks() if autonomy_mod._ready else []
        if tasks:
            print("\nALTROS: Pending tasks:")
            for t in tasks:
                print(f"  [{t.get('priority',5)}/10] {t['title']}")
        else:
            print("\nALTROS: Koi pending task nahi. Clean slate!\n")
        return True, False

    if cmd == "books":
        try:
            count = knowledge_mod._collection.count() if knowledge_mod._ready else 0
            print(f"\nALTROS: Knowledge base mein {count} chunks hain.\n")
        except Exception:
            print("ALTROS: Knowledge module ready nahi.\n")
        return True, False

    if cmd.startswith("remember "):
        parts = user_input[9:].split(" ", 1)
        if len(parts) == 2:
            memory.remember(parts[0], parts[1])
            print(f"ALTROS: Yaad kar liya — {parts[0]}: {parts[1]}\n")
        return True, False

    if cmd.startswith("voice"):
        if not MODULES_ENABLED.get("voice"):
            print("ALTROS: Voice disabled. config.py mein enable karo.\n")
            return True, False
        parts = cmd.split()
        duration = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 5
        spoken = voice_mod.listen(duration=duration)
        if not spoken:
            print("ALTROS: Kuch sunai nahi diya.\n")
            return True, False
        memory.extract_and_store(spoken)
        response = router.route(spoken)
        memory.add_message("user", spoken)
        memory.add_message("assistant", response)
        voice_mod.speak(response)
        return True, False

    return False, False


def main():
    # --add-book mode
    if len(sys.argv) >= 3 and sys.argv[1] == "--add-book":
        book_path = sys.argv[2]
        memory, brain, router, knowledge_mod, voice_mod, ww, server, autonomy = boot()
        knowledge_mod.add_document(book_path)
        return

    voice_mode = "--voice" in sys.argv
    memory, brain, router, knowledge_mod, voice_mod, wake_word_mod, server_mod, autonomy_mod = boot()

    # Start server
    if MODULES_ENABLED.get("server"):
        server_mod.set_dependencies(router, memory, voice_mod)
        server_mod.start()
        try:
            import ngrok
            if NGROK_AUTHTOKEN:
                ngrok.set_auth_token(NGROK_AUTHTOKEN)
            listener = ngrok.forward(SERVER_PORT)
            print(f"📱 Phone access URL: {listener.url()}")
        except Exception as e:
            print(f"📱 Phone access unavailable: {e}")

    # Autonomy — start reminders
    if MODULES_ENABLED.get("autonomy") and autonomy_mod._ready:
        def reminder_callback(msg):
            print(f"\n⏰ ALTROS: {msg}\n")
        autonomy_mod.set_callback(reminder_callback)
        autonomy_mod.start()

    # Wake word
    if MODULES_ENABLED.get("wake_word") and wake_word_mod._ready:
        def activate_voice():
            spoken = voice_mod.listen(duration=6)
            if spoken:
                memory.extract_and_store(spoken)
                response = router.route(spoken)
                memory.add_message("user", spoken)
                memory.add_message("assistant", response)
                voice_mod.speak(response)
        wake_word_mod.start(callback=activate_voice)

    # Keyboard shortcut
    try:
        import keyboard
        def activate_voice_kb():
            spoken = voice_mod.listen(duration=6)
            if spoken:
                memory.extract_and_store(spoken)
                response = router.route(spoken)
                memory.add_message("user", spoken)
                memory.add_message("assistant", response)
                voice_mod.speak(response)
        keyboard.add_hotkey("ctrl+alt+a", activate_voice_kb)
        print("⌨️  Shortcut: Ctrl+Alt+A")
    except Exception:
        pass

    # Daily briefing on startup
    if autonomy_mod._ready:
        briefing = autonomy_mod.get_daily_briefing()
        print(f"\n📋 {briefing}\n")

    # Voice mode
    if voice_mode:
        print("ALTROS: Voice mode on! Ctrl+C se band karo.\n")
        voice_mod.speak("ALTROS ready hai. Bolo Manish.")
        while True:
            try:
                spoken = voice_mod.listen(duration=6)
                if not spoken: continue
                if "stop" in spoken.lower() or "band" in spoken.lower():
                    voice_mod.speak("Theek hai. Chalte hain.")
                    break
                memory.extract_and_store(spoken)
                response = router.route(spoken)
                memory.add_message("user", spoken)
                memory.add_message("assistant", response)
                voice_mod.speak(response)
            except KeyboardInterrupt:
                print("\nALTROS: Chalte hain. 👋\n")
                memory.clear_session()
                break
        return

    # Main chat loop
    while True:
        try:
            user_input = input(f"{USER_NAME}: ").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n\nALTROS: Chalte hain, {USER_NAME}! 👋\n")
            memory.clear_session()
            break

        if not user_input:
            continue

        handled, should_exit = handle_command(
            user_input, memory, knowledge_mod, voice_mod, router, autonomy_mod
        )
        if should_exit: break
        if handled: continue

        memory.extract_and_store(user_input)
        response = router.route(user_input)
        memory.add_message("user", user_input)
        memory.add_message("assistant", response)


if __name__ == "__main__":
    main()