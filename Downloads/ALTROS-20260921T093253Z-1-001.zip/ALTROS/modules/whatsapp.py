# ============================================================
#  ALTROS Module: WhatsApp Integration
#  whatsapp_bridge.js se communicate karta hai
# ============================================================

import re
import requests
from modules.base import BaseModule

BRIDGE_URL = "http://localhost:8001"

WA_TRIGGERS = [
    "whatsapp", "msg kar", "message kar", "bhej do",
    "send kar", "bata do", "forward", "reply kar",
    "file bhej", "photo bhej", "contact", "chat"
]


class WhatsAppModule(BaseModule):
    name = "whatsapp"
    description = "WhatsApp — send/receive messages and files"

    def __init__(self):
        self._ready = False
        self._pending_messages: list[dict] = []

    def on_enable(self):
        try:
            r = requests.get(f"{BRIDGE_URL}/status", timeout=3)
            if r.status_code == 200:
                self._ready = True
                print("     ✅ WhatsApp module ready")
            else:
                print("     ⚠️  WhatsApp bridge chal raha hai? 'node whatsapp_bridge.js' run karo")
        except Exception:
            print("     ⚠️  WhatsApp bridge nahi mila. 'node whatsapp_bridge.js' run karo")

    def can_handle(self, query: str, context: dict) -> bool:
        if not self._ready:
            return False
        q = query.lower()
        return any(t in q for t in WA_TRIGGERS)

    def handle(self, query: str, context: dict) -> str:
        q = query.lower()

        # Send message
        if any(w in q for w in ["msg kar", "message kar", "bhej do", "send kar", "bata do"]):
            number, message, name = self._extract_msg_details(query, context)
            if not number:
                return f"WhatsApp: Kis ko message karna hai? Number ya naam batao."
            if not message:
                return f"WhatsApp: Kya message bhejun?"
            return self._send_message(number, message, name)

        # Send file
        if any(w in q for w in ["file bhej", "photo bhej", "send file"]):
            number, filepath, caption = self._extract_file_details(query, context)
            if not number:
                return "WhatsApp: Kis ko file bhejni hai?"
            if not filepath:
                return "WhatsApp: Kaunsi file bhejni hai? Path batao."
            return self._send_file(number, filepath, caption)

        # Get contacts
        if "contact" in q or "contacts" in q:
            return self._get_contacts()

        return ""

    def add_incoming_message(self, sender: str, message: str, is_owner: bool):
        """Called when new WhatsApp message arrives."""
        self._pending_messages.append({
            "sender": sender,
            "message": message,
            "is_owner": is_owner
        })
        if len(self._pending_messages) > 50:
            self._pending_messages = self._pending_messages[-50:]

    def get_pending_summary(self) -> str:
        if not self._pending_messages:
            return ""
        msgs = self._pending_messages[-5:]
        lines = [f"📱 {len(self._pending_messages)} WhatsApp messages aaye:"]
        for m in msgs:
            lines.append(f"  - {m['sender']}: {m['message'][:50]}")
        self._pending_messages = []
        return "\n".join(lines)

    def _send_message(self, number: str, message: str, name: str = "") -> str:
        try:
            r = requests.post(f"{BRIDGE_URL}/send",
                json={"number": number, "message": message}, timeout=15)
            if r.status_code == 200:
                return f"WhatsApp: Message bhej diya {name or number} ko ✅\n'{message}'"
            return f"WhatsApp: Send error — {r.text}"
        except Exception as e:
            return f"WhatsApp: Error — {e}"

    def _send_file(self, number: str, filepath: str, caption: str = "") -> str:
        try:
            r = requests.post(f"{BRIDGE_URL}/send-file",
                json={"number": number, "filepath": filepath, "caption": caption},
                timeout=30)
            if r.status_code == 200:
                return f"WhatsApp: File bhej di ✅"
            return f"WhatsApp: File error — {r.text}"
        except Exception as e:
            return f"WhatsApp: Error — {e}"

    def _get_contacts(self) -> str:
        try:
            r = requests.get(f"{BRIDGE_URL}/contacts", timeout=10)
            data = r.json()
            contacts = data.get("contacts", [])
            if not contacts:
                return "WhatsApp: Koi contact nahi mila."
            lines = [f"WhatsApp Contacts ({len(contacts)}):"]
            for c in contacts[:20]:
                lines.append(f"  - {c['name']}: {c['number']}")
            return "\n".join(lines)
        except Exception as e:
            return f"WhatsApp: Error — {e}"

    def _extract_msg_details(self, query: str, context: dict):
        """Query se number/naam aur message extract karo."""
        profile = context.get("profile", {})

        # Number extract — 10 digit
        number_match = re.search(r'\b(91)?[6-9]\d{9}\b', query)
        number = number_match.group() if number_match else None

        # Quotes mein message
        msg_match = re.search(r'"([^"]+)"', query)
        message = msg_match.group(1) if msg_match else None

        # Naam se number dhundo (profile mein saved)
        name = None
        if not number:
            words = query.split()
            for i, word in enumerate(words):
                if word.lower() in ["ko", "se"] and i > 0:
                    name = words[i-1]
                    # Profile mein check karo
                    saved = profile.get(f"contact_{name.lower()}")
                    if saved:
                        number = saved

        return number, message, name

    def _extract_file_details(self, query: str, context: dict):
        number_match = re.search(r'\b(91)?[6-9]\d{9}\b', query)
        number = number_match.group() if number_match else None

        path_match = re.search(r'[A-Za-z]:\\[^\s"]+', query)
        filepath = path_match.group() if path_match else None

        caption_match = re.search(r'"([^"]+)"', query)
        caption = caption_match.group(1) if caption_match else ""

        return number, filepath, caption
