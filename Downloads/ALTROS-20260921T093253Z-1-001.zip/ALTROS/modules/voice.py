# ============================================================
#  ALTROS Module: Voice (Phase 2)
#  Whisper STT (small model, CPU) + pyttsx3 TTS
# ============================================================

import numpy as np
import sounddevice as sd
import pyttsx3
import whisper
from modules.base import BaseModule


class VoiceModule(BaseModule):
    name = "voice"
    description = "Whisper STT + pyttsx3 TTS — offline voice I/O"

    def __init__(self):
        self._whisper_model = None
        self._tts_engine = None
        self._sample_rate = 16000
        self._ready = False

    def on_enable(self):
        try:
            print("     🎙️  Whisper small model load ho raha hai (CPU)...")
            self._whisper_model = whisper.load_model("small", device="cpu")

            self._tts_engine = pyttsx3.init()
            self._tts_engine.setProperty("rate", 165)
            self._tts_engine.setProperty("volume", 1.0)

            voices = self._tts_engine.getProperty("voices")
            for v in voices:
                if "english" in v.name.lower() or "en_" in v.id.lower():
                    self._tts_engine.setProperty("voice", v.id)
                    break

            self._ready = True
            print("     ✅ Voice module ready")

        except Exception as e:
            print(f"     ⚠️  Voice module error: {e}")
            self._ready = False

    def can_handle(self, query: str, context: dict) -> bool:
        return False

    def handle(self, query: str, context: dict) -> str:
        return ""

    def listen(self, duration: int = 5) -> str:
        if not self._ready:
            print("⚠️  Voice module ready nahi hai.")
            return ""

        print(f"\n🎙️  Bol raha hoon... ({duration} sec) — ABHI BOLO!")

        try:
            audio = sd.rec(
                int(duration * self._sample_rate),
                samplerate=self._sample_rate,
                channels=1,
                dtype="float32",
                device=1,
            )
            sd.wait()
            audio_np = audio.flatten()

            volume = float(np.abs(audio_np).mean())
            print(f"     [mic volume: {volume:.4f}]")

            if volume < 0.01:
                print("⚠️  Awaaz bahut kam hai. Mic ke paas bolo.")
                return ""

            print("🔄 Samajh raha hoon...")

            result = self._whisper_model.transcribe(
                audio_np,
                language="en",
                task="transcribe",
                fp16=False,
                temperature=0.0,
                no_speech_threshold=0.6,
                condition_on_previous_text=False,
            )

            text = result["text"].strip()

            if not text or len(text) < 2:
                print("⚠️  Kuch samajh nahi aaya. Dobara try karo.")
                return ""

            print(f"Manish (voice): {text}")
            return text

        except Exception as e:
            print(f"⚠️  Listen error: {e}")
            return ""

    def speak(self, text: str):
        if not self._ready or not text:
            if text:
                print(f"ALTROS: {text}")
            return

        try:
            clean = ""
            for ch in text:
                if ord(ch) < 128:
                    clean += ch
                else:
                    clean += " "
            clean = clean.strip()

            if clean:
                self._tts_engine.say(clean)
                self._tts_engine.runAndWait()
            else:
                print(f"ALTROS (text): {text}")

        except Exception as e:
            print(f"⚠️  Speak error: {e}")
            print(f"ALTROS: {text}")