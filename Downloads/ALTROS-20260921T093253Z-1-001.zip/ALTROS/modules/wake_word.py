# ============================================================
#  ALTROS Module: Wake Word (Phase 2)
#  pvporcupine 4.x compatible
# ============================================================

import threading
import struct
from modules.base import BaseModule


class WakeWordModule(BaseModule):
    name = "wake_word"
    description = "Porcupine wake word — 'computer' se activate"

    def __init__(self):
        self._ready = False
        self._porcupine = None
        self._listening = False
        self._callback = None
        self._thread = None

    def on_enable(self):
        try:
            import pvporcupine
            from config import PORCUPINE_ACCESS_KEY, WAKE_WORD

            if not PORCUPINE_ACCESS_KEY:
                print("     ⚠️  Wake word disabled — set PORCUPINE_ACCESS_KEY to enable it")
                return

            self._porcupine = pvporcupine.create(
                access_key=PORCUPINE_ACCESS_KEY,
                keywords=[WAKE_WORD]
            )
            self._ready = True
            print(f"     ✅ Wake word ready — '{WAKE_WORD}' bolo activate karne ke liye")

        except Exception as e:
            print(f"     ⚠️  Wake word error: {e}")

    def can_handle(self, query: str, context: dict) -> bool:
        return False

    def handle(self, query: str, context: dict) -> str:
        return ""

    def start(self, callback):
        if not self._ready:
            return
        self._callback = callback
        self._listening = True
        self._thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._thread.start()
        print(f"🎙️  Wake word listener background mein chal raha hai...")

    def stop(self):
        self._listening = False

    def _listen_loop(self):
        try:
            import sounddevice as sd
            from config import WAKE_WORD

            sample_rate  = self._porcupine.sample_rate
            frame_length = self._porcupine.frame_length

            with sd.RawInputStream(
                samplerate=sample_rate,
                channels=1,
                dtype="int16",
                blocksize=frame_length,
                device=1,
            ) as stream:
                while self._listening:
                    data, _ = stream.read(frame_length)
                    pcm = struct.unpack_from("h" * frame_length, bytes(data))
                    result = self._porcupine.process(pcm)
                    if result >= 0:
                        print(f"\n🔔 '{WAKE_WORD}' suna! ALTROS activate...\n")
                        if self._callback:
                            self._callback()
        except Exception as e:
            print(f"⚠️  Wake word listener error: {e}")