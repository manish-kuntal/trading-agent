# ============================================================
#  ALTROS Module: PC Control (Phase 4) — with Security Layer
#  File/Folder ops + App control + System commands
# ============================================================

import os
import re
import shutil
import subprocess
from modules.base import BaseModule

USERNAME  = os.getenv("USERNAME", "manish kuntal")
DESKTOP   = f"C:\\Users\\{USERNAME}\\Desktop"
DOCS      = f"C:\\Users\\{USERNAME}\\Documents"
DOWNLOADS = f"C:\\Users\\{USERNAME}\\Downloads"

# ── SECURITY: Restricted commands ────────────────────────────
RESTRICTED_COMMANDS = [
    "format", "del /f /s", "rm -rf", "deltree",
    "reg delete", "bcdedit", "diskpart",
    "netsh firewall", "cipher /w", "sfc /scannow"
]

CONTROL_TRIGGERS = [
    "open", "kholo", "launch", "start", "chalu",
    "close", "band karo", "shutdown", "restart",
    "volume", "mute", "screenshot", "screenshort",
    "folder", "file", "banao", "create", "delete",
    "copy", "move", "cut", "rename", "hata do",
    "notepad", "chrome", "brave", "edge", "discord",
    "instagram", "youtube", "whatsapp",
    "calculator", "explorer", "task manager",
    "desktop", "documents", "downloads",
    "list karo", "dikhao", "files dikhao"
]

APPS = {
    "chrome"        : "start chrome",
    "google chrome" : "start chrome",
    "browser"       : "start chrome",
    "brave"         : "start brave",
    "edge"          : "start msedge",
    "microsoft edge": "start msedge",
    "vs code"       : "code .",
    "vscode"        : "code .",
    "code"          : "code .",
    "discord"       : "start discord",
    "teams"         : "start msteams",
    "telegram"      : "start telegram",
    "whatsapp"      : "start https://web.whatsapp.com",
    "instagram"     : "start https://www.instagram.com",
    "facebook"      : "start https://www.facebook.com",
    "youtube"       : "start https://www.youtube.com",
    "google"        : "start https://www.google.com",
    "chatgpt"       : "start https://chat.openai.com",
    "github"        : "start https://github.com",
    "gmail"         : "start https://mail.google.com",
    "calculator"    : "calc",
    "calc"          : "calc",
    "notepad"       : "notepad",
    "file explorer" : "explorer",
    "explorer"      : "explorer",
    "task manager"  : "taskmgr",
    "settings"      : "start ms-settings:",
    "snipping tool" : "snippingtool",
    "paint"         : "mspaint",
    "cmd"           : "start cmd",
    "terminal"      : "start cmd",
    "powershell"    : "start powershell",
    "word"          : "start winword",
    "excel"         : "start excel",
    "powerpoint"    : "start powerpnt",
    "spotify"       : "start spotify",
    "vlc"           : "start vlc",
    "android studio": "start studio64.exe",
    "adobe"         : "start C:\\Program Files (x86)\\Adobe\\Adobe Creative Cloud\\ACC\\Creative Cloud.exe",
    "afterburner"   : "start MSIAfterburner.exe",
    "realtek"       : "start RtkNGUI64.exe",
    "rockstar"      : "start C:\\Program Files\\Rockstar Games\\Launcher\\LauncherPatcher.exe",
    "microsoft store": "start ms-windows-store:",
    "bluestacks"    : "start HD-Player.exe",
}


class PCControlModule(BaseModule):
    name = "pc_control"
    description = "File/folder ops + app control + system commands"

    def __init__(self):
        self._ready = False
        self._safe_mode = True  # Security: confirm before dangerous ops

    def on_enable(self):
        self._ready = True
        print("     ✅ PC Control module ready")

    def can_handle(self, query: str, context: dict) -> bool:
        if not self._ready:
            return False
        q = query.lower()
        return any(t in q for t in CONTROL_TRIGGERS)

    def handle(self, query: str, context: dict) -> str:
        q = query.lower()

        # ── SECURITY CHECK ────────────────────────────────────
        for restricted in RESTRICTED_COMMANDS:
            if restricted in q:
                return f"PC Control: ⛔ Ye command restricted hai — system damage ho sakta hai. Safe mode ON hai."

        # ── 1. APP OPEN ───────────────────────────────────────
        sorted_apps = sorted(APPS.keys(), key=len, reverse=True)
        if any(w in q for w in ["open", "kholo", "launch", "start", "chalu"]):
            for app_name in sorted_apps:
                if app_name in q:
                    try:
                        subprocess.Popen(APPS[app_name], shell=True)
                        return f"PC Control: {app_name} kar diya bhai. ✅"
                    except Exception as e:
                        return f"PC Control: {app_name} error — {e}"

        # ── 2. SYSTEM COMMANDS ────────────────────────────────
        if "shutdown cancel" in q:
            subprocess.Popen("shutdown /a", shell=True)
            return "PC Control: Shutdown cancel ho gaya."

        if "shutdown" in q or "shut down" in q:
            subprocess.Popen("shutdown /s /t 15", shell=True)
            return "PC Control: ⚠️ Laptop 15 sec mein band hoga. Cancel karna ho: 'shutdown cancel' bolo."

        if "restart" in q:
            subprocess.Popen("shutdown /r /t 15", shell=True)
            return "PC Control: ⚠️ Laptop 15 sec mein restart hoga."

        if "screenshot" in q or "screenshort" in q:
            try:
                import pyautogui
                from datetime import datetime
                path = os.path.join(DESKTOP, f"screenshot_{datetime.now().strftime('%H%M%S')}.png")
                pyautogui.screenshot(path)
                return f"PC Control: Screenshot save ho gaya — {path} ✅"
            except Exception as e:
                return f"PC Control: Screenshot error — {e}"

        if "volume up" in q:
            try:
                import pyautogui
                for _ in range(5): pyautogui.press("volumeup")
                return "PC Control: Volume badhaa diya. 🔊"
            except Exception as e:
                return f"PC Control: Error — {e}"

        if "volume down" in q:
            try:
                import pyautogui
                for _ in range(5): pyautogui.press("volumedown")
                return "PC Control: Volume kam kar diya. 🔉"
            except Exception as e:
                return f"PC Control: Error — {e}"

        if "mute" in q:
            try:
                import pyautogui
                pyautogui.press("volumemute")
                return "PC Control: Volume mute/unmute. 🔇"
            except Exception as e:
                return f"PC Control: Error — {e}"

        # ── 3. FOLDER/FILE OPS ────────────────────────────────
        if any(w in q for w in ["create", "banao", "bana", "new folder"]):
            if "folder" in q or "directory" in q:
                name = self._extract_name(query)
                path = self._extract_path(q, name)
                try:
                    os.makedirs(path, exist_ok=True)
                    return f"PC Control: Folder '{name}' ban gaya — {path} ✅"
                except Exception as e:
                    return f"PC Control: Folder error — {e}"

        if any(w in q for w in ["delete", "hata do", "remove"]):
            name = self._extract_name(query)
            path = self._find_item(q, name)
            if not path:
                return f"PC Control: '{name}' nahi mila."
            # Security: confirm for delete
            if self._safe_mode:
                return f"PC Control: ⚠️ '{name}' delete karna chahte ho? Confirm karo: 'haan delete karo {name}'"
            try:
                if os.path.isdir(path): shutil.rmtree(path)
                else: os.remove(path)
                return f"PC Control: '{name}' delete ho gaya. ✅"
            except Exception as e:
                return f"PC Control: Delete error — {e}"

        if q.startswith("haan delete karo"):
            name = query.replace("haan delete karo", "").strip()
            path = self._find_item(q, name)
            if path:
                try:
                    if os.path.isdir(path): shutil.rmtree(path)
                    else: os.remove(path)
                    return f"PC Control: '{name}' delete ho gaya. ✅"
                except Exception as e:
                    return f"PC Control: Error — {e}"

        if "copy" in q:
            name = self._extract_name(query)
            src  = self._find_item(q, name)
            dest = self._extract_dest(q)
            if not src: return f"PC Control: '{name}' nahi mila."
            if not dest: return "PC Control: Destination batao."
            try:
                dest_path = os.path.join(dest, os.path.basename(src))
                if os.path.isdir(src): shutil.copytree(src, dest_path)
                else: shutil.copy2(src, dest_path)
                return f"PC Control: '{name}' copy ho gaya. ✅"
            except Exception as e:
                return f"PC Control: Copy error — {e}"

        if any(w in q for w in ["move", "shift"]):
            name = self._extract_name(query)
            src  = self._find_item(q, name)
            dest = self._extract_dest(q)
            if not src: return f"PC Control: '{name}' nahi mila."
            if not dest: return "PC Control: Destination batao."
            try:
                shutil.move(src, os.path.join(dest, os.path.basename(src)))
                return f"PC Control: '{name}' move ho gaya. ✅"
            except Exception as e:
                return f"PC Control: Move error — {e}"

        if any(w in q for w in ["rename", "naam badlo"]):
            parts = re.findall(r'"([^"]+)"', query)
            if len(parts) >= 2:
                old_path = self._find_item(q, parts[0])
                if not old_path: return f"PC Control: '{parts[0]}' nahi mila."
                new_path = os.path.join(os.path.dirname(old_path), parts[1])
                try:
                    os.rename(old_path, new_path)
                    return f"PC Control: '{parts[0]}' → '{parts[1]}' ✅"
                except Exception as e:
                    return f"PC Control: Rename error — {e}"
            return 'PC Control: Format: rename "purana" to "naya"'

        if any(w in q for w in ["list", "dikhao", "files dikhao"]):
            path = self._extract_path(q, "")
            if not path or not os.path.exists(path):
                path = DESKTOP
            try:
                items = os.listdir(path)
                out = f"PC Control: '{path}' mein {len(items)} items:\n"
                for item in items[:20]:
                    tag = "[D]" if os.path.isdir(os.path.join(path, item)) else "[F]"
                    out += f"  {tag} {item}\n"
                if len(items) > 20:
                    out += f"  ... aur {len(items)-20} items"
                return out
            except Exception as e:
                return f"PC Control: List error — {e}"

        if "open" in q or "kholo" in q:
            path = self._extract_path(q, "")
            if path and os.path.exists(path):
                subprocess.Popen(f'explorer "{path}"', shell=True)
                return f"PC Control: '{path}' explorer mein khola. ✅"

        for app_name in sorted_apps:
            if app_name in q:
                try:
                    subprocess.Popen(APPS[app_name], shell=True)
                    return f"PC Control: {app_name} khol diya. ✅"
                except Exception as e:
                    return f"PC Control: {app_name} error — {e}"

        return ""

    def _extract_name(self, query: str) -> str:
        match = re.search(r'"([^"]+)"', query)
        if match: return match.group(1)
        match = re.search(r'(?:named?|naam|called?)\s+["\']?(\w+)["\']?', query, re.I)
        if match: return match.group(1)
        skip = {"folder","file","create","delete","banao","karo","the","and","for","open","kholo","a","an","on","in","at","is","desktop","documents"}
        words = [w for w in query.split() if w.lower() not in skip and len(w) > 1]
        return words[-1] if words else "new_folder"

    def _extract_path(self, q: str, name: str) -> str:
        if "desktop" in q: return os.path.join(DESKTOP, name) if name else DESKTOP
        if "documents" in q: return os.path.join(DOCS, name) if name else DOCS
        if "downloads" in q: return os.path.join(DOWNLOADS, name) if name else DOWNLOADS
        if "c drive" in q or "in c" in q: return f"C:\\{name}" if name else "C:\\"
        if "d drive" in q: return f"D:\\{name}" if name else "D:\\"
        match = re.search(r'([a-zA-Z]:\\[^\s]+)', q)
        if match:
            base = match.group(1)
            return os.path.join(base, name) if name else base
        return os.path.join(DESKTOP, name) if name else DESKTOP

    def _find_item(self, q: str, name: str) -> str:
        candidates = [
            self._extract_path(q, name),
            os.path.join(DESKTOP, name),
            os.path.join(DOCS, name),
            os.path.join(DOWNLOADS, name),
            f"C:\\{name}",
        ]
        for c in candidates:
            if os.path.exists(c): return c
        return ""

    def _extract_dest(self, q: str) -> str:
        if "desktop" in q: return DESKTOP
        if "documents" in q: return DOCS
        if "downloads" in q: return DOWNLOADS
        if "d drive" in q: return "D:\\"
        if "c drive" in q: return "C:\\"
        match = re.search(r'(?:to|mein|into)\s+([a-zA-Z]:\\[^\s]+)', q)
        if match: return match.group(1)
        return ""