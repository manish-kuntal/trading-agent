const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const http = require('http');
const fs = require('fs');

const ALTROS_API = 'http://localhost:8000';
const BRIDGE_PORT = 8001;
const OWNER_NUMBER = '917300663556';

const client = new Client({
    authStrategy: new LocalAuth({ dataPath: './wa_session' }),
    puppeteer: { headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] }
});

client.on('qr', (qr) => {
    console.log('\n📱 QR Code scan karo WhatsApp se:\n');
    qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
    console.log('✅ WhatsApp connected!');
});

// Incoming messages
client.on('message', async (msg) => {
    const sender = msg.from;
    const body = msg.body;
    const isOwner = sender.includes(OWNER_NUMBER);
    console.log(`📨 ${sender}: ${body}`);

    try {
        // Notify ALTROS
        await fetch(`${ALTROS_API}/whatsapp/incoming`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sender, message: body, isOwner })
        }).catch(() => {});

        // Agar owner "altros" se start kare — reply karo
        if (isOwner && body.toLowerCase().startsWith('altros')) {
            const command = body.slice(6).trim();
            const res = await fetch(`${ALTROS_API}/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text: command })
            });
            const data = await res.json();
            await msg.reply(data.response);
        }
    } catch (e) {
        console.log('Error:', e.message);
    }
});

// HTTP server for Python to call
const server = http.createServer(async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }

    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', async () => {
        try {
            const data = JSON.parse(body || '{}');

            if (req.url === '/send' && req.method === 'POST') {
                const chatId = data.number.includes('@') ? data.number : `${data.number}@c.us`;
                await client.sendMessage(chatId, data.message);
                res.writeHead(200);
                res.end(JSON.stringify({ status: 'sent' }));
            }
            else if (req.url === '/send-file' && req.method === 'POST') {
                const chatId = data.number.includes('@') ? data.number : `${data.number}@c.us`;
                if (!fs.existsSync(data.filepath)) {
                    res.writeHead(404);
                    res.end(JSON.stringify({ error: 'File nahi mili' }));
                    return;
                }
                const media = MessageMedia.fromFilePath(data.filepath);
                await client.sendMessage(chatId, media, { caption: data.caption || '' });
                res.writeHead(200);
                res.end(JSON.stringify({ status: 'sent' }));
            }
            else if (req.url === '/contacts') {
                const contacts = await client.getContacts();
                const list = contacts.filter(c => c.name && c.isMyContact)
                    .map(c => ({ name: c.name, number: c.number })).slice(0, 100);
                res.writeHead(200);
                res.end(JSON.stringify({ contacts: list }));
            }
            else if (req.url === '/status') {
                res.writeHead(200);
                res.end(JSON.stringify({ status: 'online' }));
            }
            else {
                res.writeHead(404);
                res.end(JSON.stringify({ error: 'Not found' }));
            }
        } catch (e) {
            res.writeHead(500);
            res.end(JSON.stringify({ error: e.message }));
        }
    });
});

server.listen(BRIDGE_PORT, () => console.log(`🌉 Bridge running on port ${BRIDGE_PORT}`));
client.initialize();
