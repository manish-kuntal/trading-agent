from fastapi import APIRouter
router = APIRouter(tags=["trades"])

@router.get("/trades")
async def get_trades(date: str = None):
    # TODO: query Trade table from DB
    return {"trades": [], "count": 0}
