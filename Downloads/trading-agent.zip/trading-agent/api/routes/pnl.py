from fastapi import APIRouter
router = APIRouter(tags=["pnl"])

@router.get("/pnl/today")
async def get_today_pnl():
    # TODO: query DailyPnL table
    return {"date": "", "realized_pnl": 0.0, "unrealized_pnl": 0.0, "trades": 0}

@router.get("/pnl/history")
async def get_pnl_history(days: int = 30):
    # TODO: last N days from DailyPnL table
    return {"history": []}
