from fastapi import APIRouter
router = APIRouter(tags=["positions"])

@router.get("/positions")
async def get_positions():
    # TODO Phase 4+: return from broker.get_positions()
    # TODO: return from DB for historical
    return {"positions": [], "count": 0}
