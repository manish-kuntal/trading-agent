import uuid
from datetime import datetime
from loguru import logger
from .base_broker import BaseBroker


class VirtualBroker(BaseBroker):
    """
    Paper trading broker.
    Uses REAL market data from Angel One, virtual money.
    Phase 1-3 only. Identical interface to AngelBroker.
    """

    def __init__(self, capital: float = 100_000.0):
        self.initial_capital = capital
        self.capital         = capital
        self.positions: dict = {}   # symbol → {qty, entry_price, token, sl_trigger}
        self.trades:    list = []   # completed trades today
        self._angel          = None # real broker for data only

    # ------------------------------------------------------------------
    def login(self) -> bool:
        from .angel_broker import AngelBroker
        self._angel = AngelBroker()
        ok = self._angel.login()
        if ok:
            logger.info(f"[VirtualBroker] PAPER MODE — capital ₹{self.capital:,.0f}")
        return ok

    def get_ltp(self, exchange: str, symbol: str, token: str) -> float:
        return self._angel.get_ltp(exchange, symbol, token)

    def get_candles(self, token: str, interval: str,
                    from_date: str, to_date: str) -> list:
        return self._angel.get_candles(token, interval, from_date, to_date)

    # ------------------------------------------------------------------
    def place_order(self, symbol: str, token: str,
                    action: str, qty: int) -> str:
        ltp         = self.get_ltp("NSE", symbol, token)
        order_id    = f"V{uuid.uuid4().hex[:6].upper()}"
        trade_value = ltp * qty

        if action == "BUY":
            if trade_value > self.capital:
                logger.warning(f"[Paper] Insufficient capital ₹{self.capital:,.0f} < ₹{trade_value:,.0f}")
                return ""
            self.capital -= trade_value
            self.positions[symbol] = {
                "qty": qty, "entry_price": ltp,
                "token": token, "entry_time": datetime.now(),
                "sl_trigger": None,
            }
            logger.info(f"[Paper] BUY  {qty}x {symbol} @ ₹{ltp} | Capital left ₹{self.capital:,.0f}")

        elif action == "SELL":
            if symbol not in self.positions:
                logger.warning(f"[Paper] No position in {symbol} to sell")
                return ""
            pos = self.positions.pop(symbol)
            pnl = (ltp - pos["entry_price"]) * qty
            self.capital += ltp * qty
            self.trades.append({
                "symbol": symbol, "qty": qty,
                "entry": pos["entry_price"], "exit": ltp,
                "pnl": pnl, "time": datetime.now(),
            })
            logger.info(f"[Paper] SELL {qty}x {symbol} @ ₹{ltp} | PnL ₹{pnl:+.2f}")

        return order_id

    def place_stoploss(self, symbol: str, token: str, action: str,
                       qty: int, trigger: float, price: float) -> str:
        """Store SL level — checked on each candle in risk manager."""
        if symbol in self.positions:
            self.positions[symbol]["sl_trigger"] = trigger
            logger.info(f"[Paper] SL set for {symbol} @ ₹{trigger}")
        return f"VSL_{symbol}"

    def get_positions(self) -> list:
        result = []
        for symbol, pos in self.positions.items():
            try:
                ltp = self.get_ltp("NSE", symbol, pos["token"])
                unrealised = (ltp - pos["entry_price"]) * pos["qty"]
            except Exception:
                ltp, unrealised = pos["entry_price"], 0.0
            result.append({
                "tradingsymbol": symbol,
                "symboltoken":   pos["token"],
                "netqty":        str(pos["qty"]),
                "ltp":           str(ltp),
                "unrealised":    str(unrealised),
            })
        return result

    def close_all_positions(self):
        logger.info(f"[Paper] Squaring off {len(self.positions)} position(s)")
        for symbol, pos in list(self.positions.items()):
            self.place_order(symbol, pos["token"], "SELL", pos["qty"])

    # ------------------------------------------------------------------
    # Paper-only helpers
    # ------------------------------------------------------------------
    @property
    def daily_pnl(self) -> float:
        return sum(t["pnl"] for t in self.trades)

    @property
    def total_value(self) -> float:
        unrealised = 0.0
        for symbol, pos in self.positions.items():
            try:
                ltp = self.get_ltp("NSE", symbol, pos["token"])
                unrealised += (ltp - pos["entry_price"]) * pos["qty"]
            except Exception:
                pass
        return self.capital + unrealised

    def summary(self) -> dict:
        return {
            "capital":         self.capital,
            "initial_capital": self.initial_capital,
            "daily_pnl":       self.daily_pnl,
            "total_value":     self.total_value,
            "open_positions":  len(self.positions),
            "trades_today":    len(self.trades),
        }
