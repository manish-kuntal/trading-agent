from sqlalchemy import Column, String, Float, Integer, DateTime, Boolean, Text
from sqlalchemy.orm import DeclarativeBase
from datetime import datetime


class Base(DeclarativeBase):
    pass


class Trade(Base):
    __tablename__ = "trades"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    symbol        = Column(String(20), nullable=False, index=True)
    token         = Column(String(10))
    action        = Column(String(4))          # BUY | SELL
    qty           = Column(Integer)
    entry_price   = Column(Float)
    exit_price    = Column(Float, nullable=True)
    sl_price      = Column(Float, nullable=True)
    pnl           = Column(Float, nullable=True)
    signal_conf   = Column(Float)
    signal_reason = Column(Text)
    llm_decision  = Column(String(4))         # LLM filter output
    order_id      = Column(String(50))
    sl_order_id   = Column(String(50), nullable=True)
    is_paper      = Column(Boolean, default=True)
    entry_time    = Column(DateTime, default=datetime.utcnow, index=True)
    exit_time     = Column(DateTime, nullable=True)


class DailyPnL(Base):
    __tablename__ = "daily_pnl"

    id            = Column(Integer, primary_key=True)
    date          = Column(String(10), unique=True, index=True)  # YYYY-MM-DD
    realized_pnl  = Column(Float, default=0.0)
    unrealized_eod= Column(Float, default=0.0)
    trades_count  = Column(Integer, default=0)
    win_count     = Column(Integer, default=0)
    capital_eod   = Column(Float)
    is_paper      = Column(Boolean, default=True)


class AgentLog(Base):
    __tablename__ = "agent_logs"

    id        = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    symbol    = Column(String(20), nullable=True)
    event     = Column(String(30))    # SIGNAL | ORDER | SL_HIT | SQUAREOFF | ERROR | LOGIN
    details   = Column(Text)
    is_paper  = Column(Boolean, default=True)
