"""
LLM Filter (Phase 2+)
---------------------
Asks local Qwen3:14b (via Ollama) for a final BUY/SELL/HOLD check
before placing any order.

Uses YOUR machine's GPU (RTX 4050) — no API cost.
Falls back to Anthropic Claude API if Ollama is unavailable.
"""
import json
import httpx
from loguru import logger
from config.settings import settings


PROMPT_TEMPLATE = """You are an intraday trading assistant for NSE (Indian stock market).
Given this market data, reply with ONLY a JSON object, no extra text.

Stock: {symbol}
Current Price: ₹{ltp}
Signal: {signal} (confidence: {confidence:.0%})
Indicators: RSI={rsi:.1f}, EMA9={ema9:.1f} vs EMA21={ema21:.1f}, VWAP={vwap:.1f}
Volume Ratio: {vol_ratio:.1f}x average

Reply format (JSON only):
{{"decision": "BUY" | "SELL" | "HOLD", "reason": "one sentence"}}
"""


class LLMFilter:

    def __init__(self):
        self.use_local = settings.use_local_llm
        self.enabled   = True

    async def validate(self, symbol: str, signal_action: str,
                       confidence: float, features: dict) -> tuple[str, str]:
        """
        Returns (decision, reason).
        decision: BUY | SELL | HOLD
        If LLM is unavailable, returns the original signal unchanged.
        """
        prompt = PROMPT_TEMPLATE.format(
            symbol=symbol,
            ltp=features.get("close", 0),
            signal=signal_action,
            confidence=confidence,
            rsi=features.get("RSI_14", 50),
            ema9=features.get("EMA_9", 0),
            ema21=features.get("EMA_21", 0),
            vwap=features.get("VWAP_D", 0),
            vol_ratio=features.get("volume_ratio", 1.0),
        )

        if self.use_local:
            return await self._ollama(prompt, signal_action)
        else:
            return await self._claude(prompt, signal_action)

    async def _ollama(self, prompt: str, fallback: str) -> tuple[str, str]:
        """Call Qwen3:14b via Ollama (localhost:11434)."""
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.post(
                    f"{settings.ollama_base_url}/api/generate",
                    json={
                        "model":  settings.ollama_model,
                        "prompt": prompt,
                        "stream": False,
                        "options": {"temperature": 0.1},
                    }
                )
            text = resp.json()["response"].strip()
            data = json.loads(text)
            return data["decision"], data.get("reason", "")
        except Exception as e:
            logger.warning(f"[Ollama] Failed: {e} — using signal as-is")
            return fallback, "LLM unavailable"

    async def _claude(self, prompt: str, fallback: str) -> tuple[str, str]:
        """Anthropic Claude API fallback."""
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
            msg = client.messages.create(
                model="claude-haiku-4-5-20251001",  # Cheapest, fastest
                max_tokens=100,
                messages=[{"role": "user", "content": prompt}]
            )
            text = msg.content[0].text.strip()
            data = json.loads(text)
            return data["decision"], data.get("reason", "")
        except Exception as e:
            logger.warning(f"[Claude] Failed: {e} — using signal as-is")
            return fallback, "LLM unavailable"
