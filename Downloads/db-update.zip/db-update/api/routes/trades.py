from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from api.deps import get_db
from agent.db import repository

router = APIRouter(tags=["trades"])


@router.get("/trades")
def get_trades(
    days: int = Query(default=1, description="Last N days"),
    db: Session = Depends(get_db)
):
    rows = repository.get_trade_history(db, days=days)
    result = []
    for t in rows:
        result.append({
            "id":           t.id,
            "symbol":       t.symbol,
            "action":       t.action,
            "qty":          t.qty,
            "entry_price":  t.entry_price,
            "exit_price":   t.exit_price,
            "pnl":          t.pnl,
            "signal_conf":  t.signal_conf,
            "is_paper":     t.is_paper,
            "entry_time":   t.entry_time.isoformat() if t.entry_time else None,
            "exit_time":    t.exit_time.isoformat()  if t.exit_time  else None,
            "status":       "OPEN" if t.exit_price is None else "CLOSED",
        })
    return {"trades": result, "count": len(result)}
