from agent.db.database import SessionLocal, init_db
from config.settings import settings

# Init DB when API starts (in case agent is not running)
try:
    if SessionLocal is None:
        init_db(settings.database_url)
except Exception:
    init_db(settings.database_url)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
