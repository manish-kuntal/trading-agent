import uuid
from datetime import datetime
from loguru import logger
from .base_broker import BaseBroker


class VirtualBroker(BaseBroker):
    """Paper trading broker — real market data, virtual money, saves to SQLite."""

    def __init__(self, capital: float = 100_000.0):
        self.initial_capital = capital
        self.capital         = capital
        self.positions: dict = {}   # symbol → {qty, entry_price, token, sl_trigger, trade_id}
        self.trades:    list = []   # completed trades (in-memory summary)
        self._angel          = None

    def login(self) -> bool:
        from .angel_broker import AngelBroker
        from agent.db.database import get_session
        from agent.db import repository

        self._angel = AngelBroker()
        ok = self._angel.login()
        if ok:
            logger.info(f"[VirtualBroker] PAPER MODE — capital ₹{self.capital:,.0f}")
            with get_session() as db:
                repository.log_event(db, "LOGIN", details="VirtualBroker started")
        return ok

    # ── DATA (delegate to Angel) ───────────────────────────────────────
    def get_ltp(self, exchange: str, symbol: str, token: str) -> float:
        return self._angel.get_ltp(exchange, symbol, token)

    def get_candles(self, token: str, interval: str,
                    from_date: str, to_date: str) -> list:
        return self._angel.get_candles(token, interval, from_date, to_date)

    # ── ORDERS ────────────────────────────────────────────────────────
    def place_order(self, symbol: str, token: str,
                    action: str, qty: int,
                    signal_conf: float = 0.0,
                    signal_reason: str = "") -> str:
        from agent.db.database import get_session
        from agent.db import repository

        ltp         = self.get_ltp("NSE", symbol, token)
        order_id    = f"V{uuid.uuid4().hex[:6].upper()}"
        trade_value = ltp * qty

        if action == "BUY":
            if trade_value > self.capital:
                logger.warning(
                    f"[Paper] Insufficient capital ₹{self.capital:,.0f} < ₹{trade_value:,.0f}"
                )
                return ""
            self.capital -= trade_value

            with get_session() as db:
                trade_id = repository.save_trade_entry(
                    db, symbol, token, "BUY", qty, ltp,
                    signal_conf=signal_conf,
                    signal_reason=signal_reason,
                    order_id=order_id, is_paper=True
                )
                repository.upsert_open_position(db, symbol, token, qty, ltp)
                repository.log_event(
                    db, "ORDER",
                    symbol=symbol,
                    details=f"BUY {qty}x @ ₹{ltp} | conf={signal_conf:.2f}"
                )

            self.positions[symbol] = {
                "qty": qty, "entry_price": ltp,
                "token": token, "entry_time": datetime.now(),
                "sl_trigger": None, "trade_id": trade_id,
            }
            logger.info(f"[Paper] BUY  {qty}x {symbol} @ ₹{ltp} | Capital ₹{self.capital:,.0f}")

        elif action == "SELL":
            if symbol not in self.positions:
                logger.warning(f"[Paper] No position in {symbol} to sell")
                return ""
            pos = self.positions.pop(symbol)
            pnl = round((ltp - pos["entry_price"]) * qty, 2)
            self.capital += ltp * qty

            with get_session() as db:
                repository.update_trade_exit(db, pos["trade_id"], ltp)
                repository.remove_open_position(db, symbol)
                repository.log_event(
                    db, "ORDER",
                    symbol=symbol,
                    details=f"SELL {qty}x @ ₹{ltp} | PnL ₹{pnl:+.2f}"
                )

            self.trades.append({
                "symbol": symbol, "qty": qty,
                "entry": pos["entry_price"], "exit": ltp,
                "pnl": pnl, "time": datetime.now(),
            })
            logger.info(f"[Paper] SELL {qty}x {symbol} @ ₹{ltp} | PnL ₹{pnl:+.2f}")

        return order_id

    def place_stoploss(self, symbol: str, token: str, action: str,
                       qty: int, trigger: float, price: float) -> str:
        from agent.db.database import get_session
        from agent.db import repository

        if symbol in self.positions:
            self.positions[symbol]["sl_trigger"] = trigger
            with get_session() as db:
                repository.upsert_open_position(
                    db, symbol, token,
                    self.positions[symbol]["qty"],
                    self.positions[symbol]["entry_price"],
                    sl_trigger=trigger
                )
        return f"VSL_{symbol}"

    def get_positions(self) -> list:
        result = []
        for symbol, pos in self.positions.items():
            try:
                ltp = self.get_ltp("NSE", symbol, pos["token"])
                unrealised = round((ltp - pos["entry_price"]) * pos["qty"], 2)
            except Exception:
                ltp, unrealised = pos["entry_price"], 0.0
            result.append({
                "tradingsymbol": symbol,
                "symboltoken":   pos["token"],
                "netqty":        str(pos["qty"]),
                "ltp":           str(ltp),
                "unrealised":    str(unrealised),
                "entry_price":   str(pos["entry_price"]),
            })
        return result

    def close_all_positions(self):
        from agent.db.database import get_session
        from agent.db import repository

        logger.info(f"[Paper] Squaring off {len(self.positions)} position(s)")
        with get_session() as db:
            repository.log_event(db, "SQUAREOFF",
                                  details=f"Closing {len(self.positions)} positions")
        for symbol, pos in list(self.positions.items()):
            self.place_order(symbol, pos["token"], "SELL", pos["qty"])

        # Save daily P&L to DB
        with get_session() as db:
            closed = [t for t in self.trades]
            wins   = sum(1 for t in closed if t["pnl"] > 0)
            repository.save_daily_pnl(
                db,
                realized_pnl=self.daily_pnl,
                trades_count=len(closed),
                win_count=wins,
                capital_eod=self.total_value
            )

    # ── HELPERS ───────────────────────────────────────────────────────
    @property
    def daily_pnl(self) -> float:
        return round(sum(t["pnl"] for t in self.trades), 2)

    @property
    def total_value(self) -> float:
        unrealised = 0.0
        for symbol, pos in self.positions.items():
            try:
                ltp = self.get_ltp("NSE", symbol, pos["token"])
                unrealised += (ltp - pos["entry_price"]) * pos["qty"]
            except Exception:
                pass
        return round(self.capital + unrealised, 2)

    def summary(self) -> dict:
        return {
            "capital":         round(self.capital, 2),
            "initial_capital": self.initial_capital,
            "daily_pnl":       self.daily_pnl,
            "total_value":     self.total_value,
            "open_positions":  len(self.positions),
            "trades_today":    len(self.trades),
        }
