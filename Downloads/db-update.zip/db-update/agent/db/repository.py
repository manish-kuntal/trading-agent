from datetime import datetime, date, timedelta
from sqlalchemy.orm import Session
from agent.db.models import Trade, OpenPosition, DailyPnL, AgentLog


# ── TRADES ────────────────────────────────────────────────────────────
def save_trade_entry(db: Session, symbol: str, token: str, action: str,
                     qty: int, entry_price: float, signal_conf: float = 0.0,
                     signal_reason: str = "", order_id: str = "",
                     is_paper: bool = True) -> int:
    trade = Trade(
        symbol=symbol, token=token, action=action, qty=qty,
        entry_price=entry_price, signal_conf=signal_conf,
        signal_reason=signal_reason, order_id=order_id,
        is_paper=is_paper, entry_time=datetime.now()
    )
    db.add(trade)
    db.flush()
    return trade.id


def update_trade_exit(db: Session, trade_id: int, exit_price: float):
    trade = db.query(Trade).filter(Trade.id == trade_id).first()
    if not trade:
        return
    trade.exit_price = exit_price
    trade.exit_time  = datetime.now()
    if trade.action == "BUY":
        trade.pnl = round((exit_price - trade.entry_price) * trade.qty, 2)
    else:
        trade.pnl = round((trade.entry_price - exit_price) * trade.qty, 2)


def get_today_trades(db: Session, is_paper: bool = True) -> list:
    today_start = datetime.combine(date.today(), datetime.min.time())
    return (db.query(Trade)
              .filter(Trade.entry_time >= today_start, Trade.is_paper == is_paper)
              .order_by(Trade.entry_time.desc())
              .all())


def get_trade_history(db: Session, days: int = 30) -> list:
    from_dt = datetime.now() - timedelta(days=days)
    return (db.query(Trade)
              .filter(Trade.entry_time >= from_dt)
              .order_by(Trade.entry_time.desc())
              .all())


# ── OPEN POSITIONS ────────────────────────────────────────────────────
def upsert_open_position(db: Session, symbol: str, token: str,
                          qty: int, entry_price: float,
                          sl_trigger: float = None, is_paper: bool = True):
    pos = db.query(OpenPosition).filter(OpenPosition.symbol == symbol).first()
    if pos:
        pos.qty        = qty
        pos.sl_trigger = sl_trigger
        pos.updated_at = datetime.now()
    else:
        pos = OpenPosition(
            symbol=symbol, token=token, qty=qty,
            entry_price=entry_price, sl_trigger=sl_trigger,
            is_paper=is_paper, entry_time=datetime.now()
        )
        db.add(pos)


def remove_open_position(db: Session, symbol: str):
    db.query(OpenPosition).filter(OpenPosition.symbol == symbol).delete()


def get_open_positions(db: Session) -> list:
    return db.query(OpenPosition).all()


# ── P&L ───────────────────────────────────────────────────────────────
def get_today_pnl(db: Session, is_paper: bool = True) -> dict:
    trades = get_today_trades(db, is_paper)
    closed = [t for t in trades if t.pnl is not None]
    realized = round(sum(t.pnl for t in closed), 2)
    wins     = sum(1 for t in closed if t.pnl > 0)
    return {
        "date":          date.today().isoformat(),
        "realized_pnl":  realized,
        "trades_count":  len(trades),
        "closed_count":  len(closed),
        "open_count":    len(trades) - len(closed),
        "win_count":     wins,
        "win_rate":      round(wins / len(closed) * 100, 1) if closed else 0.0,
    }


def get_pnl_history(db: Session, days: int = 30) -> list:
    from_date = (date.today() - timedelta(days=days)).isoformat()
    return (db.query(DailyPnL)
              .filter(DailyPnL.date >= from_date)
              .order_by(DailyPnL.date.desc())
              .all())


def save_daily_pnl(db: Session, realized_pnl: float, trades_count: int,
                    win_count: int, capital_eod: float, is_paper: bool = True):
    today = date.today().isoformat()
    row   = db.query(DailyPnL).filter(DailyPnL.date == today).first()
    if row:
        row.realized_pnl = realized_pnl
        row.trades_count = trades_count
        row.win_count    = win_count
        row.capital_eod  = capital_eod
    else:
        db.add(DailyPnL(
            date=today, realized_pnl=realized_pnl,
            trades_count=trades_count, win_count=win_count,
            capital_eod=capital_eod, is_paper=is_paper
        ))


# ── LOGS ──────────────────────────────────────────────────────────────
def log_event(db: Session, event: str, symbol: str = None,
              details: str = "", is_paper: bool = True):
    db.add(AgentLog(event=event, symbol=symbol,
                    details=details, is_paper=is_paper))
