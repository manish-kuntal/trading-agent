from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from contextlib import contextmanager
from loguru import logger

engine       = None
SessionLocal = None


def init_db(database_url: str = "sqlite:///./trading.db"):
    global engine, SessionLocal
    from agent.db.models import Base
    engine = create_engine(
        database_url,
        connect_args={"check_same_thread": False}
    )
    SessionLocal = sessionmaker(bind=engine)
    Base.metadata.create_all(bind=engine)
    logger.info(f"DB initialised: {database_url}")


@contextmanager
def get_session():
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
